# PuffinZipAI_Project/puffinzip_ai/rle_utils.py

RLE_ERROR_NO_COUNT = "ERROR_INVALID_RLE_FORMAT_NO_COUNT"
RLE_ERROR_BAD_COUNT = "ERROR_INVALID_RLE_FORMAT_BAD_COUNT"
RLE_ERROR_NO_CHAR = "ERROR_INVALID_RLE_FORMAT_NO_CHAR"
RLE_DECOMPRESSION_ERRORS = {
    RLE_ERROR_NO_COUNT,
    RLE_ERROR_BAD_COUNT,
    RLE_ERROR_NO_CHAR
}


def rle_compress(text_data: str) -> str:
    if not isinstance(text_data, str):
        raise TypeError("Input data for RLE compression must be a string.")
    if not text_data:
        return ""

    result_parts = []
    n = len(text_data)
    if n == 0:
        return ""

    count = 1
    current_char = text_data[0]
    for i in range(1, n):
        if text_data[i] == current_char:
            count += 1
        else:
            result_parts.append(str(count))
            result_parts.append(current_char)
            current_char = text_data[i]
            count = 1
    result_parts.append(str(count))
    result_parts.append(current_char)
    return "".join(result_parts)


def rle_decompress(compressed_text_data: str) -> str:
    if not isinstance(compressed_text_data, str):
        raise TypeError("Input data for RLE decompression must be a string.")
    if not compressed_text_data:
        return ""

    result_parts = []
    i = 0
    n = len(compressed_text_data)

    while i < n:
        num_str = ""
        start_i_num = i
        while i < n and compressed_text_data[i].isdigit():
            num_str += compressed_text_data[i]
            i += 1

        if not num_str:
            # Error logged by PuffinZipAI class if necessary, just return error code
            return RLE_ERROR_NO_COUNT
        try:
            count = int(num_str)
        except ValueError:
            return RLE_ERROR_BAD_COUNT
        if i < n:
            char_to_decompress = compressed_text_data[i]
            result_parts.append(char_to_decompress * count)
            i += 1
        else:
            return RLE_ERROR_NO_CHAR

    return "".join(result_parts)