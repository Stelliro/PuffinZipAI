# PuffinZipAI_Project/puffinzip_ai/ai_core.py
import threading
import queue
import random
import numpy
import os
import time
import shutil
import sys

try:
    from .logger import setup_logger
    import logging
except ImportError:
    print("CRITICAL: puffinzip_ai.logger module not found. Using DummyLogger.")


    class DummyLogger:
        def __init__(self, name='DummyLogger'): self.name = name

        def info(self, msg, *args, **kwargs): print(f"DUMMY_INFO ({self.name}): {msg}")

        def warning(self, msg, *args, **kwargs): print(f"DUMMY_WARN ({self.name}): {msg}")

        def error(self, msg, *args, **kwargs): print(f"DUMMY_ERR ({self.name}): {msg}")

        def exception(self, msg, *args, **kwargs): print(f"DUMMY_EXC ({self.name}): {msg}")

        def debug(self, msg, *args, **kwargs): print(f"DUMMY_DEBUG ({self.name}): {msg}")

        def critical(self, msg, *args, **kwargs): print(f"DUMMY_CRIT ({self.name}): {msg}")

        def setLevel(self, level): pass

        disabled = False;
        level = 0;
        handlers = []


    class DummyLoggingModule:
        INFO = 20;WARNING = 30;ERROR = 40;DEBUG = 10;CRITICAL = 50;NOTSET = 0


    logging = DummyLoggingModule()


    def setup_logger(logger_name, log_filename=None, log_level=None, log_to_console=False, console_level=None,
                     max_bytes=0, backup_count=0):
        return DummyLogger(logger_name)

try:
    from .config import (
        MODEL_FILE_DEFAULT, DEFAULT_LEN_THRESHOLDS, COMPRESSED_FILE_SUFFIX,
        DEFAULT_LEARNING_RATE, DEFAULT_DISCOUNT_FACTOR,
        DEFAULT_EXPLORATION_DECAY_RATE, DEFAULT_MIN_EXPLORATION_RATE,
        DEFAULT_BATCH_COMPRESS_EXTENSIONS
    )
    from .rle_utils import rle_compress, rle_decompress, RLE_DECOMPRESSION_ERRORS
except ImportError as e:
    print(f"CRITICAL: Could not import from .config or .rle_utils in ai_core.py: {e}. Using hardcoded defaults.")
    MODEL_FILE_DEFAULT = "puffinzip_model.dat";
    DEFAULT_LEN_THRESHOLDS = [10, 20];
    COMPRESSED_FILE_SUFFIX = ".pzip.rle"
    DEFAULT_LEARNING_RATE = 0.1;
    DEFAULT_DISCOUNT_FACTOR = 0.9;
    DEFAULT_EXPLORATION_DECAY_RATE = 0.999;
    DEFAULT_MIN_EXPLORATION_RATE = 0.01
    DEFAULT_BATCH_COMPRESS_EXTENSIONS = ['.txt', '.log', '.csv']


    def rle_compress(text_data):
        raise NotImplementedError("rle_utils was not imported correctly")


    def rle_decompress(compressed_text_data):
        raise NotImplementedError("rle_utils was not imported correctly")


    RLE_DECOMPRESSION_ERRORS = set()


class PuffinZipAI:
    NUM_UNIQUE_RATIO_CATS = 3
    NUM_RUN_CATS = 3

    def __init__(self, len_thresholds=None):
        self.logger = setup_logger(logger_name='PuffinZipAI_Core', log_filename='logs/puffin_ai_core.log',
                                   log_level=logging.INFO, log_to_console=False, console_level=logging.DEBUG)
        self.len_thresholds = list(len_thresholds) if len_thresholds is not None else list(DEFAULT_LEN_THRESHOLDS)
        self.action_names = {0: "RLE", 1: "NoCompression"}
        self.action_space_size = len(self.action_names)
        self.gui_stop_event = None
        self.gui_output_queue = None
        self.learning_rate = DEFAULT_LEARNING_RATE
        self.discount_factor = DEFAULT_DISCOUNT_FACTOR
        self.exploration_rate = 1.0
        self.exploration_decay_rate = DEFAULT_EXPLORATION_DECAY_RATE
        self.min_exploration_rate = DEFAULT_MIN_EXPLORATION_RATE
        self.training_stats = {'total_items_processed': 0, 'cumulative_reward': 0.0, 'decomp_errors': 0,
                               'rle_chosen_count': 0, 'nocomp_chosen_count': 0}
        self._reinitialize_state_dependent_vars()
        self.logger.info(
            f"PuffinZipAI initialized. Thresholds: {self.len_thresholds}, LR: {self.learning_rate}, Discount: {self.discount_factor}, Expl. Rate: {self.exploration_rate:.4f}")

    def _send_to_gui(self, message):
        if self.gui_output_queue:
            try:
                self.gui_output_queue.put_nowait(str(message))
            except queue.Full:
                self.logger.warning(f"GUI queue full. Message dropped: {str(message)[:100]}...")
        else:
            print(message)

    def _reinitialize_state_dependent_vars(self):
        self.NUM_LEN_CATS = len(self.len_thresholds) + 1
        self.state_space_size = self.NUM_LEN_CATS * self.NUM_UNIQUE_RATIO_CATS * self.NUM_RUN_CATS
        self.q_table = numpy.zeros((self.state_space_size, self.action_space_size))
        self.logger.info(f"State reinitialized. NUM_LEN_CATS: {self.NUM_LEN_CATS}, Q-table: {self.q_table.shape}")
        self.training_stats = {'total_items_processed': 0, 'cumulative_reward': 0.0, 'decomp_errors': 0,
                               'rle_chosen_count': 0, 'nocomp_chosen_count': 0, 'reward_history': [],
                               'exploration_history': []}

    def configure_data_categories(self, new_len_thresholds_str_list):
        user_msg = "";
        parsed_thresholds = []
        try:
            if new_len_thresholds_str_list and any(s.strip() for s in new_len_thresholds_str_list):
                parsed_thresholds = sorted(
                    list(set(int(t.strip()) for t in new_len_thresholds_str_list if t.strip().isdigit())))

            if not parsed_thresholds and any(s.strip() for s in new_len_thresholds_str_list):
                user_msg = "Invalid threshold values. Using defaults."
                self.logger.warning(f"{user_msg} Input: {new_len_thresholds_str_list}")
                self.len_thresholds = list(DEFAULT_LEN_THRESHOLDS)
            elif not parsed_thresholds:
                user_msg = "Empty thresholds provided. Using defaults."
                self.logger.info(f"{user_msg} User input: {new_len_thresholds_str_list}")
                self.len_thresholds = list(DEFAULT_LEN_THRESHOLDS)
            else:
                self.len_thresholds = parsed_thresholds;
                user_msg = f"Data categories updated. Length thresholds: {self.len_thresholds}. Model has been reset."

            self._reinitialize_state_dependent_vars();
            self.exploration_rate = 1.0
            self.logger.info(user_msg + " Q-table and exploration rate reset.");
            self._send_to_gui(user_msg)
            return True
        except ValueError:
            user_msg = "Invalid format for thresholds. Please enter comma-separated numbers."
            self.logger.warning(f"{user_msg} User input: {new_len_thresholds_str_list}", exc_info=True);
            self._send_to_gui(user_msg)
            return False
        except Exception as e:
            user_msg = f"Error configuring data categories: {str(e)}";
            self.logger.exception(user_msg);
            self._send_to_gui(f"Error: {user_msg}");
            return False

    def _get_state_representation(self, item_text):
        length = len(item_text)
        unique_chars = len(set(item_text)) if length > 0 else 0
        len_cat = len(self.len_thresholds)
        for i, threshold in enumerate(self.len_thresholds):
            if length < threshold: len_cat = i; break
        unique_ratio_cat = 0
        if length > 0:
            ratio = unique_chars / length
            if ratio < 0.5:
                unique_ratio_cat = 0
            elif ratio < 0.8:
                unique_ratio_cat = 1
            else:
                unique_ratio_cat = 2
        max_run_val, current_run_val = 0, 0
        if length > 0:
            current_run_val = 1
            for i in range(1, length):
                if item_text[i] == item_text[i - 1]:
                    current_run_val += 1
                else:
                    max_run_val = max(max_run_val, current_run_val); current_run_val = 1
            max_run_val = max(max_run_val, current_run_val)
        run_cat = 0
        if max_run_val < 3:
            run_cat = 0
        elif max_run_val < 6:
            run_cat = 1
        else:
            run_cat = 2

        state_index = (len_cat * (PuffinZipAI.NUM_UNIQUE_RATIO_CATS * PuffinZipAI.NUM_RUN_CATS) +
                       unique_ratio_cat * PuffinZipAI.NUM_RUN_CATS +
                       run_cat)
        return state_index

    def _choose_action(self, state_index, use_exploration=True):
        action = 0
        if use_exploration and random.random() < self.exploration_rate:
            action = random.randint(0, self.action_space_size - 1)
        else:
            action = numpy.argmax(self.q_table[state_index])

        if use_exploration:
            if action == 0:
                self.training_stats['rle_chosen_count'] += 1
            else:
                self.training_stats['nocomp_chosen_count'] += 1
        self.logger.debug(
            f"State {state_index}: Chose action: {self.action_names[action]} (Explore: {use_exploration and random.random() < self.exploration_rate}). Q-vals: {self.q_table[state_index, :] if self.q_table.shape[0] > state_index else 'N/A - Q-table too small'}")
        return action

    def _update_q_table(self, state_index, action_index, reward):
        current_q = self.q_table[state_index, action_index]
        new_q = current_q + self.learning_rate * (reward - current_q)
        self.q_table[state_index, action_index] = new_q
        self.logger.debug(
            f"Q-table updated: S={state_index}, A={self.action_names[action_index]}, R={reward:.3f}, OldQ={current_q:.3f}, NewQ={new_q:.3f}")

    def _generate_random_item(self, min_len=5, max_len=40, prob_long_run=0.60, prob_varied_run=0.25):
        length = random.randint(min_len, max_len)
        if length == 0: return ""

        alphabet_chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
        alphabet_digits = "0123456789"
        alphabet_symbols = "!@#$%^&*()_+-=[]{};':\",./<>? "
        full_alphabet = list(alphabet_chars + alphabet_digits + alphabet_symbols)

        item_chars = []
        rand_type = random.random()

        if rand_type < prob_long_run:
            num_segments = random.randint(1, max(1, length // 15 if length > 15 else 1))
            avg_len_per_segment = length // num_segments if num_segments > 0 else length  # Initialize avg_len_per_segment
            for _ in range(num_segments):
                if len(item_chars) >= length: break
                char_to_repeat = random.choice(alphabet_chars if alphabet_chars else full_alphabet)
                run_length = min(random.randint(1, max(2, avg_len_per_segment + 5)), length - len(item_chars))
                if run_length > 0: item_chars.extend([char_to_repeat] * run_length)
        elif rand_type < prob_long_run + prob_diverse_chars:
            if length > 0:
                item_chars = [random.choice(full_alphabet) for _ in range(length)]
        else:
            while len(item_chars) < length:
                char_to_repeat = random.choice(full_alphabet)
                run_length = min(random.randint(1, 12), length - len(item_chars))
                if run_length > 0: item_chars.extend([char_to_repeat] * run_length)

        if len(item_chars) > length:
            item_chars = item_chars[:length]
        while len(item_chars) < length and full_alphabet:
            item_chars.append(random.choice(full_alphabet))

        return "".join(item_chars)

    def _process_batch(self, batch_experiences, source_info="", rewards_accumulator=None):
        batch_len = len(batch_experiences)
        if batch_len == 0: return 0.0
        self.logger.debug(
            f"Processing batch ({batch_len}) from {source_info}. Expl.Rate before: {self.exploration_rate:.4f}")
        sum_reward_in_batch = 0.0
        items_actually_processed_in_batch = 0
        for i, (state_idx, action_idx, reward, item_text_snippet, action_name, compressed_data_snippet,
                decompressed_data_snippet, decomp_mismatch_flag) in enumerate(batch_experiences):
            if self.gui_stop_event and self.gui_stop_event.is_set():
                if i > 0 and (i % 20 == 0 or i == batch_len - 1): time.sleep(0.001)
                self.logger.info(
                    f"Stop event detected during _process_batch from {source_info} after processing {items_actually_processed_in_batch} of {batch_len} items.")
                break

            items_actually_processed_in_batch += 1
            if decomp_mismatch_flag:
                self.logger.warning(
                    f"BatchProcessing ({source_info}): Decomp mismatch. Item:'{item_text_snippet}', Act:{action_name}, Comp:'{compressed_data_snippet}', Decomp:'{decompressed_data_snippet}'")
            self._update_q_table(state_idx, action_idx, reward)
            self.exploration_rate = max(self.min_exploration_rate, self.exploration_rate * self.exploration_decay_rate)
            sum_reward_in_batch += reward
            if i > 0 and i % 100 == 0: time.sleep(0.001)

        if rewards_accumulator is not None and items_actually_processed_in_batch > 0:
            rewards_accumulator.extend([exp[2] for exp in batch_experiences[:items_actually_processed_in_batch]])

        avg_reward_this_batch = sum_reward_in_batch / items_actually_processed_in_batch if items_actually_processed_in_batch > 0 else 0.0
        self.logger.debug(
            f"Batch from {source_info} processed. Items: {items_actually_processed_in_batch}. AvgRwd: {avg_reward_this_batch:.3f}. ExplRate: {self.exploration_rate:.4f}")
        return avg_reward_this_batch

    def _handle_item_processing_for_training(self, item_text, source_id, item_counter_info=""):
        state_index = self._get_state_representation(item_text)
        action_index = self._choose_action(state_index, use_exploration=True)
        original_size = len(item_text)
        reward = 0.0;
        decomp_mismatch_flag = False
        action_name_for_msg = self.action_names[action_index]
        compressed_data, decompressed_data, compressed_size = "", "", original_size

        if original_size == 0:
            reward = 1.0
        else:
            compressed_data = rle_compress(item_text) if action_index == 0 else item_text
            decompressed_data = rle_decompress(compressed_data) if action_index == 0 else item_text
            compressed_size = len(compressed_data)

            if decompressed_data in RLE_DECOMPRESSION_ERRORS or decompressed_data != item_text:
                reward = -10.0;
                decomp_mismatch_flag = True
                self.training_stats['decomp_errors'] += 1
                self.logger.error(
                    f"{source_id} {item_counter_info}: DECOMP_ERROR! "
                    f"OrigItem='{item_text}', Comp='{compressed_data}', DecompAttempt='{decompressed_data}'"
                )
            else:
                if compressed_size == 0 and original_size > 0:
                    reward = float(original_size) / 0.1
                elif compressed_size <= 0 and original_size == 0:
                    reward = 1.0
                else:
                    reward = float(original_size) / compressed_size

        self.training_stats['total_items_processed'] += 1
        self.training_stats['cumulative_reward'] += reward
        return state_index, action_index, reward, item_text[:50], action_name_for_msg, compressed_data[
                                                                                       :50], decompressed_data[
                                                                                             :50], decomp_mismatch_flag

    def train(self, num_episodes=None, run_continuously=False, batch_size=1):
        batch_experiences = [];
        items_in_batch = 0;
        source_id = "RandomTrain"
        processed_items_session = 0  # Initialize here
        rewards_log_batch = [];
        LOG_STATS_INTERVAL = max(1, batch_size * 50 if batch_size > 1 else 500)

        mode_description = "Continuous Random" if run_continuously else f"Fixed {num_episodes if num_episodes is not None else 0} Episodes Random"
        user_msg_start = f"Starting {mode_description} training (Batch Size: {batch_size})..."
        if run_continuously: user_msg_start += " Press Stop button to halt."
        self.logger.info(user_msg_start.split("...")[0])
        self._send_to_gui(user_msg_start)

        if not run_continuously and (num_episodes is None or num_episodes <= 0):
            self._send_to_gui("Error: Number of episodes must be a positive integer for fixed episode training.");
            return

        loop_active = True;
        current_episode_for_fixed = 0
        try:
            while loop_active:
                if self.gui_stop_event and self.gui_stop_event.is_set():
                    if batch_experiences: self._process_batch(batch_experiences, f"{source_id}-StopSignal",
                                                              rewards_log_batch)
                    batch_experiences.clear()
                    stop_msg = f"{mode_description} training stopped by request after {processed_items_session} items."
                    self.logger.info(stop_msg);
                    self._send_to_gui(stop_msg);
                    break

                if not run_continuously and processed_items_session >= num_episodes:
                    loop_active = False;
                    continue

                min_len, max_len = 5, 40;
                r = random.random()
                if r < 0.1:
                    min_len, max_len = (self.len_thresholds[-1] + 1) if self.len_thresholds else 100, (
                                                                                                          self.len_thresholds[
                                                                                                              -1] if self.len_thresholds else 100) + 150
                elif r < 0.3:
                    min_len, max_len = (self.len_thresholds[0] if self.len_thresholds else 10), (self.len_thresholds[
                                                                                                     -1] if self.len_thresholds else 50) + 50
                item = self._generate_random_item(min_len=max(1, min_len), max_len=max(min_len + 1, max_len))

                if processed_items_session > 0 and processed_items_session % 100 == 0: time.sleep(0.001)

                exp_data = self._handle_item_processing_for_training(item, source_id,
                                                                     f"Item {self.training_stats['total_items_processed'] + 1}")
                batch_experiences.append(exp_data);
                items_in_batch += 1;
                processed_items_session += 1
                if not run_continuously: current_episode_for_fixed += 1

                process_now = items_in_batch >= batch_size or \
                              (
                                          not run_continuously and current_episode_for_fixed == num_episodes and batch_experiences) or \
                              (self.gui_stop_event and self.gui_stop_event.is_set() and batch_experiences)

                if process_now and batch_experiences:
                    avg_reward_batch = self._process_batch(batch_experiences,
                                                           f"{source_id}-Batch-{self.training_stats['total_items_processed'] // batch_size if batch_size > 0 else self.training_stats['total_items_processed']}",
                                                           rewards_log_batch)
                    batch_experiences.clear();
                    items_in_batch = 0
                    if self.gui_stop_event and self.gui_stop_event.is_set(): self.logger.info(
                        f"{mode_description}: Stop ack after batch."); break

                if self.training_stats['total_items_processed'] % LOG_STATS_INTERVAL == 0 and self.training_stats[
                    'total_items_processed'] > 0:
                    avg_reward_recent_str = "N/A"
                    if rewards_log_batch: avg_reward_recent_str = f"{sum(rewards_log_batch) / len(rewards_log_batch):.3f}"; rewards_log_batch.clear()
                    rle_p = (self.training_stats['rle_chosen_count'] / self.training_stats[
                        'total_items_processed'] * 100) if self.training_stats['total_items_processed'] > 0 else 0
                    status = (
                        f"{mode_description}: {processed_items_session} items. Total: {self.training_stats['total_items_processed']}. "
                        f"AvgRwd(last ~{LOG_STATS_INTERVAL}): {avg_reward_recent_str}. Expl: {self.exploration_rate:.4f}. Errors: {self.training_stats['decomp_errors']}. RLE %: {rle_p:.1f}")
                    self.logger.info(status);
                    self._send_to_gui(status)

                if run_continuously and items_in_batch == 0: time.sleep(0.0001)

        except KeyboardInterrupt:
            self.logger.info(f"\n{mode_description} training interrupted (KB) after {processed_items_session} items.")
            self._send_to_gui(
                f"\n{mode_description} training interrupted by KeyboardInterrupt after {processed_items_session} items.")
        except Exception as e:
            self.logger.exception(f"Error during training: {e}");
            self._send_to_gui(f"ERROR during training: {e}")
        finally:
            if batch_experiences: self._process_batch(batch_experiences, f"{source_id}-Finally", rewards_log_batch)
            if self.gui_stop_event: self.gui_stop_event.clear()
            avg_total_reward_session = (
                        self.training_stats['cumulative_reward'] / self.training_stats['total_items_processed']) if \
            self.training_stats['total_items_processed'] > 0 else 0.0
            final_msg = (f"{mode_description} session ended. Session Items: {processed_items_session}. "
                         f"Total Trained: {self.training_stats['total_items_processed']}. Expl.Rate: {self.exploration_rate:.4f}. "
                         f"Overall Avg Reward: {avg_total_reward_session:.3f}.")
            self.logger.info(final_msg);
            self._send_to_gui(final_msg)

    def learn_from_folder(self, folder_path, allowed_extensions=None, run_continuously=False, batch_size=1):
        source_id = "FolderLearn";
        exts = allowed_extensions or ['.txt']
        batch_exps, items_in_batch, session_files_proc, rewards_log = [], 0, 0, []
        LOG_INTERVAL = max(1, batch_size * 10 if batch_size > 1 else 50)
        cont_str = "continuously" if run_continuously else "once"

        user_msg = f"Starting folder learn '{folder_path}' ({cont_str}, Batch: {batch_size}). Exts: {', '.join(exts)}"
        self.logger.info(user_msg);
        self._send_to_gui(user_msg)
        epoch = 0
        try:
            while True:
                if self.gui_stop_event and self.gui_stop_event.is_set(): self.logger.info(
                    f"{source_id} stopped at start of pass {epoch + 1}."); break
                epoch += 1;
                files_this_epoch = 0
                if run_continuously: self._send_to_gui(f"{source_id}(Cont.): Pass {epoch} on '{folder_path}'")

                try:
                    all_folder_items = [f for f in os.listdir(folder_path) if
                                        os.path.isfile(os.path.join(folder_path, f))]
                except FileNotFoundError:
                    self._send_to_gui(f"ERR: Folder '{folder_path}' not found (Pass {epoch})."); break

                processable = [f for f in all_folder_items if any(f.lower().endswith(ext) for ext in exts)];
                num_proc = len(processable)
                self.logger.info(f"{source_id} P{epoch}:Found {num_proc} processable files.");
                self._send_to_gui(f"Pass {epoch}: Found {num_proc} files.")
                if num_proc == 0:
                    if run_continuously:
                        self._send_to_gui(f"{source_id} P{epoch}: No files. Waiting...")
                        for _ in range(25):  # Check every 0.2s for 5s
                            if self.gui_stop_event and self.gui_stop_event.is_set(): self.logger.info(
                                f"{source_id} stopped in wait."); return
                            time.sleep(0.2)
                        continue
                    else:
                        self._send_to_gui(f"{source_id}: No files in single pass."); break

                for file_idx, fname in enumerate(processable):
                    if self.gui_stop_event and self.gui_stop_event.is_set():
                        if batch_exps: self._process_batch(batch_exps, f"{source_id}-StopSignal-P{epoch}", rewards_log)
                        self._send_to_gui(
                            f"{source_id} stopped. GlobalTotal: {self.training_stats['total_items_processed']}.");
                        return

                    fpath = os.path.join(folder_path, fname)
                    try:
                        with open(fpath, 'r', encoding='utf-8', errors='ignore') as f:
                            item_text = f.read()
                        if not item_text.strip(): self._send_to_gui(f"Skipping empty: {fname} (P{epoch})"); continue

                        exp_data = self._handle_item_processing_for_training(item_text, source_id,
                                                                             f"P{epoch}F:{fname[:20]}")
                        batch_exps.append(exp_data);
                        items_in_batch += 1;
                        files_this_epoch += 1;
                        total_session_files += 1

                        force_batch_process = (self.gui_stop_event and self.gui_stop_event.is_set() and batch_exps)
                        if items_in_batch >= batch_size or (
                                file_idx == num_proc - 1 and batch_exps) or force_batch_process:
                            if force_batch_process: self.logger.info(f"{source_id}:Stop pre-batch P{epoch}")
                            self._process_batch(batch_exps, f"{source_id}-P{epoch}-FBatchEnd", rewards_log)
                            batch_exps.clear();
                            items_in_batch = 0
                            if force_batch_process: break

                        if files_this_epoch % 10 == 0 or files_this_epoch == 1 or file_idx == num_proc - 1:
                            self._send_to_gui(
                                f"Folder(P{epoch}):{files_this_epoch}/{num_proc}.File:'{fname}'.Expl:{self.exploration_rate:.4f}")

                        if self.training_stats['total_items_processed'] % LOG_INTERVAL == 0 and rewards_log:
                            avg_rwd = sum(rewards_log) / len(rewards_log) if rewards_log else -1.0;
                            rewards_log.clear()
                            s = f"{source_id}(Tot {self.training_stats['total_items_processed']}):AvgRwd(last ~{LOG_INTERVAL}):{avg_rwd:.3f}.Expl:{self.exploration_rate:.4f}.Errs:{self.training_stats['decomp_errors']}"
                            self.logger.info(s);
                            self._send_to_gui(s.split(" Expl:")[0])
                        if file_idx > 0 and file_idx % 50 == 0: time.sleep(0.001)  # Yield during long folder scan
                    except Exception as e:
                        self.logger.exception(f"Err proc file '{fname}' (P{epoch}):{e}"); self._send_to_gui(
                            f"ERROR:{e}")

                if self.gui_stop_event and self.gui_stop_event.is_set(): self.logger.info("Stop after pass."); break
                if batch_exps: self._process_batch(batch_exps, f"{source_id}-EndOfPass{epoch}", rewards_log)
                self._send_to_gui(
                    f"{source_id}:Pass {epoch} done.Files:{files_this_epoch}.SessTotal:{total_session_files}.")
                if not run_continuously: break
                if run_continuously: time.sleep(1)  # Shorter sleep between passes
        except KeyboardInterrupt:
            self._send_to_gui(f"{source_id}({cont_str}) interrupted(KB).Sess files:{total_session_files}.")
        finally:
            if batch_exps: self._process_batch(batch_exps, f"{source_id}-Finally-P{epoch}", rewards_log)
            if self.gui_stop_event: self.gui_stop_event.clear()
            avg_total_rwd = (self.training_stats['cumulative_reward'] / self.training_stats['total_items_processed']) if \
            self.training_stats['total_items_processed'] > 0 else 0.0
            fin_msg = f"{source_id}({cont_str}) ended.SessFiles:{total_session_files}.GlobalItems:{self.training_stats['total_items_processed']}.Expl:{self.exploration_rate:.4f}.OverallAvgRwd:{avg_total_rwd:.3f}."
            self.logger.info(fin_msg);
            self._send_to_gui(fin_msg)

    def batch_compress_folder(self, input_folder_path, output_folder_path, allowed_extensions=None):
        source_id = "BatchCompress";
        exts = allowed_extensions or DEFAULT_BATCH_COMPRESS_EXTENSIONS
        user_msg = f"Starting {source_id}:'{input_folder_path}'->'{output_folder_path}'.Exts:{exts}"
        self.logger.info(user_msg);
        self._send_to_gui(user_msg)
        if not os.path.isdir(input_folder_path): self._send_to_gui(
            f"ERR:Input folder '{input_folder_path}' not found."); return
        try:
            os.makedirs(output_folder_path, exist_ok=True)
        except OSError as e:
            self._send_to_gui(f"ERR creating output folder '{output_folder_path}':{e}"); return
        counts = {'total': 0, 'rle': 0, 'copied': 0, 'empty': 0, 'error_op': 0}
        try:
            files_to_process = [f for f in os.listdir(input_folder_path) if
                                os.path.isfile(os.path.join(input_folder_path, f)) and any(
                                    f.lower().endswith(ext) for ext in exts)]
            self._send_to_gui(f"Found {len(files_to_process)} files to process.")
            for i, filename in enumerate(files_to_process):
                if self.gui_stop_event and self.gui_stop_event.is_set(): self._send_to_gui(
                    f"{source_id} stopped.Processed:{counts['total']}."); break
                if i > 0 and i % 10 == 0: time.sleep(0.001)
                in_fp = os.path.join(input_folder_path, filename);
                counts['total'] += 1
                try:
                    with open(in_fp, 'r', encoding='utf-8', errors='ignore') as f_in:
                        content = f_in.read()
                    op_key = "copy_empty" if not content.strip() else (
                        "rle_compress" if self._choose_action(self._get_state_representation(content),
                                                              False) == 0 else "copy_no_comp_decision")
                    res_key = self._perform_batch_file_op(op_key, in_fp, output_folder_path, filename,
                                                          content if op_key == "rle_compress" else None)
                    counts[res_key] = counts.get(res_key, 0) + 1
                    if counts['total'] % 10 == 0: self._send_to_gui(
                        f"{source_id} progress: {counts['total']}/{len(files_to_process)} files...")
                except Exception as e_file:
                    self.logger.exception(f"Err processing '{filename}' for {source_id}:{e_file}");
                    self._send_to_gui(f"ERROR:{e_file}");
                    counts['error_op'] += 1
                    self._perform_batch_file_op("copy_err_src", in_fp, output_folder_path, filename + ".COMP_ERROR")
            summary = f"{source_id} finished.Total:{counts['total']}.RLE:{counts['rle']}.Copied:{counts['copied']}.Empty:{counts['empty']}.Errors:{counts['error_op']}."
            self.logger.info(summary);
            self._send_to_gui(summary)
        except Exception as e:
            self.logger.exception(f"Error during {source_id}:{e}"); self._send_to_gui(f"ERROR:{e}")
        finally:
            if self.gui_stop_event: self.gui_stop_event.clear()

    def batch_decompress_folder(self, input_folder_path, output_folder_path):
        source_id = "BatchDecompress"
        self._send_to_gui(f"Starting {source_id}:'{input_folder_path}'->'{output_folder_path}'.");
        self.logger.info(f"Starting {source_id}")
        if not os.path.isdir(input_folder_path): self._send_to_gui(
            f"Error: Input folder '{input_folder_path}' not found."); return
        try:
            os.makedirs(output_folder_path, exist_ok=True)
        except OSError as e:
            self._send_to_gui(f"Error creating output folder '{output_folder_path}':{e}"); return
        counts = {'total': 0, 'ok': 0, 'fail': 0, 'copied_asis': 0, 'error_op': 0}
        try:
            all_files = [f for f in os.listdir(input_folder_path) if os.path.isfile(os.path.join(input_folder_path, f))]
            self._send_to_gui(f"Found {len(all_files)} files to process.")
            for i, filename in enumerate(all_files):
                if self.gui_stop_event and self.gui_stop_event.is_set(): self._send_to_gui(
                    f"{source_id} stopped.Processed:{counts['total']}."); break
                if i > 0 and i % 10 == 0: time.sleep(0.001)
                in_fp = os.path.join(input_folder_path, filename);
                counts['total'] += 1
                try:
                    op_key = "rle_decompress" if filename.lower().endswith(COMPRESSED_FILE_SUFFIX) else "copy_asis"
                    res_key = self._perform_batch_file_op(op_key, in_fp, output_folder_path, filename)
                    counts[res_key] = counts.get(res_key, 0) + 1
                    if counts['total'] % 10 == 0: self._send_to_gui(
                        f"{source_id} progress: {counts['total']}/{len(all_files)}...")
                except Exception as e_file:
                    self.logger.exception(f"Err processing '{filename}' for {source_id}:{e_file}");
                    self._send_to_gui(f"ERROR:{e_file}");
                    counts['error_op'] += 1
                    try:
                        shutil.copy2(in_fp, os.path.join(output_folder_path, filename + ".DECOMP_ERROR"))
                    except Exception as e_copy:
                        self.logger.error(f"Failed to copy error file {filename}:{e_copy}")
            summary = f"{source_id} done.Total:{counts['total']}.DecompOK:{counts['ok']}.DecompFail:{counts['fail']}.Copied:{counts['copied_asis']}.Errors:{counts['error_op']}."
            self.logger.info(summary);
            self._send_to_gui(summary)
        except Exception as e:
            self.logger.exception(f"Error during {source_id}:{e}"); self._send_to_gui(f"ERROR:{e}")
        finally:
            if self.gui_stop_event: self.gui_stop_event.clear()

    def _format_q_table_summary_line(self, state_index):
        if state_index < 0 or state_index >= self.state_space_size: return f"State {state_index}: Invalid"
        len_idx = state_index // (self.NUM_UNIQUE_RATIO_CATS * self.NUM_RUN_CATS)
        rem_idx = state_index % (self.NUM_UNIQUE_RATIO_CATS * self.NUM_RUN_CATS)
        uniq_idx = rem_idx // self.NUM_RUN_CATS
        run_idx = rem_idx % self.NUM_RUN_CATS
        state_desc = f"L{len_idx}U{uniq_idx}R{run_idx}"
        q_vals = self.q_table[state_index]
        pref_act_idx = numpy.argmax(q_vals)
        pref_act_name = self.action_names[pref_act_idx]
        q_info = f"{q_vals[0]:.2f} | {q_vals[1]:.2f}"
        if numpy.all(q_vals == 0):
            q_info += " (Untrained)"
        elif abs(q_vals[0] - q_vals[1]) < 0.01:
            q_info += " (Close)"
        return f"State {state_desc} ({state_index:02d}): -> {pref_act_name} ({q_info})"

    def display_q_table_summary(self):
        self.logger.debug("Q-Table Summary Requested")
        output_lines = [f"\n--- Q-Table Summary (Thresholds: {self.len_thresholds}) ---",
                        "(State:LUR -> Pref:Action (RLE_Q | NoComp_Q))",
                        f"Q-Table Shape: {self.q_table.shape if hasattr(self, 'q_table') else 'N/A'}"]
        if hasattr(self, 'q_table') and self.q_table is not None and self.q_table.size > 0:
            for i in range(self.state_space_size):  # Should match self.q_table.shape[0]
                if i >= self.q_table.shape[0]: break
                output_lines.append(self._format_q_table_summary_line(i))
        else:
            output_lines.append("Q-Table is not initialized or is empty.")
        output_lines.append("--- End Q-Table Summary ---");
        self._send_to_gui("\n".join(output_lines))

    def test_agent_on_random_items(self, num_test_items=5):
        src_id = "TestRandom"
        self.logger.info(f"Testing agent on {num_test_items} random items. Thresh: {self.len_thresholds}")
        self._send_to_gui(
            f"\n--- Testing agent on {num_test_items} new random items (using thresholds: {self.len_thresholds}) ---")
        cum_reward, tested_count = 0.0, 0
        for i in range(num_test_items):
            if self.gui_stop_event and self.gui_stop_event.is_set(): self.logger.info(
                f"{src_id} Test interrupted after {tested_count} items."); break

            min_l, max_l = 3, 45;
            r = random.random()
            if r < 0.2:
                min_l, max_l = (self.len_thresholds[-1] + 1 if self.len_thresholds else 100), (
                            (self.len_thresholds[-1] if self.len_thresholds else 100) + 50)
            elif r < 0.5:
                min_l, max_l = (self.len_thresholds[0] if self.len_thresholds else 10), (
                            (self.len_thresholds[-1] if self.len_thresholds else 50) + 20)

            item = self._generate_random_item(min_len=max(1, min_l), max_len=max(min_len + 1, max_len))
            tested_count += 1
            s_idx = self._get_state_representation(item);
            a_idx = self._choose_action(s_idx, False)
            a_name, o_size = self.action_names[a_idx], len(item);
            curr_rwd, info_str = 0.0, ""
            s_desc_line = self._format_q_table_summary_line(s_idx).split(' ->')[
                0] if s_idx < self.state_space_size else f"S_INVALID({s_idx})"
            self._send_to_gui(
                f"\nItem {i + 1}: \"{item[:60]}{'...' if len(item) > 60 else ''}\" (Size:{o_size}, State:{s_desc_line})")
            if a_idx == 0:
                comp = rle_compress(item);
                decomp = rle_decompress(comp)
                if decomp in RLE_DECOMPRESSION_ERRORS or decomp != item:
                    curr_rwd = -10.0;
                    info_str = f"RLE Chosen.DECOMP FAILED!Decomp:'{decomp[:60]}...'"
                    self.logger.error(f"Test RLE fail.Orig:'{item[:50]}',Comp:'{comp[:50]}',Decomp:'{decomp[:50]}'")
                else:
                    cs = len(comp);
                    curr_rwd = (float(o_size) / cs) if cs > 0 else (float(o_size) / 0.1 if o_size > 0 else 1.0)
                    info_str = f"RLE:'{comp[:60]}{'...' if len(comp) > 60 else ''}',Sz:{cs},Ratio:{curr_rwd:.2f}"  # use curr_rwd
            else:
                cs = o_size;curr_rwd = 1.0;info_str = f"NoComp,Sz:{cs},Ratio:{curr_rwd:.2f}"
            self._send_to_gui(f"  Agent chose:{a_name} -> {info_str}, Reward:{curr_rwd:.2f}");
            cum_reward += curr_rwd
            if i > 0 and i % 10 == 0: time.sleep(0.001)
        avg_reward = cum_reward / tested_count if tested_count > 0 else 0
        self._send_to_gui(f"\nAvg reward over {tested_count} test items: {avg_reward:.2f}\n--- End Test ---")
        self.logger.info(f"Test complete. Items:{tested_count}. Avg reward:{avg_reward:.2f}")

    def compress_user_item(self, item_text):
        log_snip = item_text[:50] + ('...' if len(item_text) > 50 else '');
        user_snip = item_text[:100] + ('...' if len(item_text) > 100 else '')
        self.logger.info(f"Compressing user item (len {len(item_text)}): '{log_snip}'")
        output = [f"\n--- Compressing: '{user_snip}' (Thresh: {self.len_thresholds}) ---"]
        if not item_text:
            output.append("Input empty.");self.logger.info("User item for compression empty.")
        else:
            s_idx = self._get_state_representation(item_text);
            a_idx = self._choose_action(s_idx, False);
            a_name = self.action_names[a_idx];
            o_size = len(item_text)
            s_desc_line = self._format_q_table_summary_line(s_idx).split(' ->')[
                0] if s_idx < self.state_space_size else f"S_INVALID({s_idx})"
            output.append(f"Orig Size:{o_size},State:{s_desc_line},AI Chose:{a_name}")
            if a_idx == 0:
                comp = rle_compress(item_text);
                decomp = rle_decompress(comp)
                if decomp in RLE_DECOMPRESSION_ERRORS or decomp != item_text:
                    output.append(f"  ERROR:RLE Comp/Decomp FAILED!Decomp:'{decomp[:60]}...'");
                    self.logger.error(f"User RLE mismatch.Orig:'{log_snip}',Comp:'{comp[:50]}',Decomp:'{decomp[:50]}'")
                else:
                    cs = len(comp);ratio = (o_size / cs) if cs > 0 else (
                        float('inf') if o_size > 0 else 1.0);output.append(
                        f"  RLE:'{comp[:100]}{'...' if len(comp) > 100 else ''}',Size:{cs},Ratio:{ratio:.2f}");self.logger.info(
                        f"User item'{log_snip}' RLE to '{comp[:50]}'.")
            else:
                output.append(f"  NoComp. Size:{o_size}");self.logger.info(f"User item '{log_snip}' decision NoComp.")
        output.append("--- End Compression ---");
        self._send_to_gui("\n".join(output))

    def decompress_user_item_rle(self, item_text):
        snip_u = item_text[:100] + ('...' if len(item_text) > 100 else '');
        self.logger.info(f"Decompressing user RLE (len {len(item_text)}):'{item_text[:50]}...'")
        output = [f"\n--- Decompressing RLE: '{snip_u}' ---"]
        if not item_text:
            output.append("Input RLE empty."); self.logger.info("User item RLE decomp empty.")
        else:
            decomp = rle_decompress(item_text)
            if decomp in RLE_DECOMPRESSION_ERRORS:
                output.append(f"  Error RLE decomp: {decomp}"); self.logger.error(
                    f"User RLE decomp fail:'{item_text[:50]}'.Reason:{decomp}")
            else:
                output.append(
                    f"  Decompressed (RLE): '{decomp[:100]}{'...' if len(decomp) > 100 else ''}'"); self.logger.info(
                    f"User RLE '{item_text[:50]}' decomp to '{decomp[:50]}'.")
        output.append("--- End Decompression ---");
        self._send_to_gui("\n".join(output))

    def save_model(self, filepath=None):
        fpath = filepath or MODEL_FILE_DEFAULT
        try:
            d_name = os.path.dirname(fpath)
            if d_name and not os.path.exists(d_name): os.makedirs(d_name, exist_ok=True)
            model_state = {'q_table': self.q_table, 'exploration_rate': self.exploration_rate,
                           'len_thresholds': self.len_thresholds, 'training_stats': self.training_stats, 'v': '1.2.2'}
            numpy.save(fpath, model_state, allow_pickle=True)
            msg = f"Model saved to '{os.path.abspath(fpath)}'. Trained items: {self.training_stats.get('total_items_processed', 0)}"
            self.logger.info(msg);
            self._send_to_gui(msg);
            return True
        except Exception as e:
            msg = f"Error saving model to '{fpath}': {e}"; self.logger.exception(msg); self._send_to_gui(
                f"ERROR:{msg}"); return False

    def load_model(self, filepath=None):
        fpath = filepath or MODEL_FILE_DEFAULT
        try:
            if not os.path.exists(fpath):
                self._send_to_gui(f"Model file '{fpath}' not found. Using new model.");
                self.logger.warning(f"Model file '{fpath}' not found.");
                return False

            data = numpy.load(fpath, allow_pickle=True).item()
            loaded_thresholds = data.get('len_thresholds', DEFAULT_LEN_THRESHOLDS)

            # Check if thresholds or expected Q-table size changed
            expected_q_table_rows_for_loaded_thresholds = (
                                                                      len(loaded_thresholds) + 1) * self.NUM_UNIQUE_RATIO_CATS * self.NUM_RUN_CATS
            current_q_table_rows = self.q_table.shape[0] if hasattr(self, 'q_table') and self.q_table is not None else 0

            reset_model_needed = False
            if list(self.len_thresholds) != list(
                    loaded_thresholds) or current_q_table_rows != expected_q_table_rows_for_loaded_thresholds:
                self.logger.info(
                    f"Model structure changed (thresholds or implied Q-table size). Reinitializing. Loaded_thresholds: {loaded_thresholds}")
                self.len_thresholds = loaded_thresholds
                self._reinitialize_state_dependent_vars()  # This resets Q-table and stats
                reset_model_needed = True  # Mark that Q-table and exploration rate should be based on defaults or what's in the file

            loaded_q_table = data.get('q_table')
            loaded_exp_rate = data.get('exploration_rate', DEFAULT_EXPLORATION_RATE)  # Use default if not found
            loaded_stats = data.get('training_stats',
                                    {'total_items_processed': 0, 'cumulative_reward': 0.0, 'decomp_errors': 0,
                                     'rle_chosen_count': 0, 'nocomp_chosen_count': 0})

            if not reset_model_needed and loaded_q_table is not None and loaded_q_table.shape == self.q_table.shape:
                self.q_table = loaded_q_table
                self.exploration_rate = loaded_exp_rate
                self.training_stats = loaded_stats
                user_msg = (
                    f"Model loaded from '{os.path.abspath(fpath)}'. TrnItems:{self.training_stats.get('total_items_processed', 0)}")
                self.logger.info(
                    f"{user_msg}. Thresh:{self.len_thresholds}, ExplRate:{self.exploration_rate:.4f}. Q-shape:{self.q_table.shape}.")
                self._send_to_gui(user_msg)
                return True
            else:
                # If model was reset OR Q-table in file doesn't match new structure (even if thresholds were same initially)
                errmsg = "Q-Table from file incompatible or not found."
                if loaded_q_table is not None and loaded_q_table.shape != self.q_table.shape:
                    errmsg += f" Expected {self.q_table.shape}, got {loaded_q_table.shape}."
                user_msg = f"Notice: {errmsg} Using fresh Q-table for thresholds: {self.len_thresholds}. Expl. rate & stats reset."
                self.logger.warning(f"{user_msg} File:'{fpath}'.")
                self.exploration_rate = DEFAULT_EXPLORATION_RATE  # Reset for a fresh Q-table
                # self._reinitialize_state_dependent_vars() would have been called if thresholds changed
                # if only Q-table was incompatible, reinitialize ensures stats are also fresh.
                if not reset_model_needed:  # If thresholds didn't change but Q-table was bad
                    self._reinitialize_state_dependent_vars()
                self._send_to_gui(user_msg);
                return True  # Consider it a 'successful load' of settings, even with fresh model
        except Exception as e:
            user_msg = f"Error loading model from '{fpath}': {e}. Using current config."
            self.logger.exception(f"Error loading model:'{fpath}'");
            self._send_to_gui(f"ERROR:{user_msg}");
            return False