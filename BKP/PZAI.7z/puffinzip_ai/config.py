# PuffinZipAI_Project/puffinzip_ai/config.py

import os

# --- File Paths ---
# Get the directory of the current file (config.py)
CONFIG_FILE_DIR = os.path.dirname(os.path.abspath(__file__))
# Assume the project root is one level up from the 'puffinzip_ai' directory
PROJECT_ROOT_DIR = os.path.dirname(CONFIG_FILE_DIR)

DATA_DIR = os.path.join(PROJECT_ROOT_DIR, "data")
MODELS_DIR = os.path.join(DATA_DIR, "models")
LOGS_DIR_NAME = "logs" # Just the name of the directory
LOGS_DIR_PATH = os.path.join(PROJECT_ROOT_DIR, LOGS_DIR_NAME) # Full path to logs directory

MODEL_FILENAME = "puffinzip_model_v1_2.dat"
MODEL_FILE_DEFAULT = os.path.join(MODELS_DIR, MODEL_FILENAME)

COMPRESSED_FILE_SUFFIX = ".pz"

# --- AI Model Parameters ---
DEFAULT_LEN_THRESHOLDS = [10, 30, 100, 500]

# --- Training Parameters ---
DEFAULT_LEARNING_RATE = 0.1
DEFAULT_DISCOUNT_FACTOR = 0.9
DEFAULT_EXPLORATION_RATE = 1.0
DEFAULT_EXPLORATION_DECAY_RATE = 0.9995
DEFAULT_MIN_EXPLORATION_RATE = 0.01
DEFAULT_TRAIN_BATCH_SIZE = 32
DEFAULT_FOLDER_LEARN_BATCH_SIZE = 16
DEFAULT_TRAIN_LOG_INTERVAL_BATCHES = 50

# --- Batch Operations ---
DEFAULT_BATCH_COMPRESS_EXTENSIONS = ['.txt', '.log', '.csv', '.json', '.xml', '.md', '.py', '.html', '.css', '.js']
DEFAULT_ALLOWED_LEARN_EXTENSIONS = ['.txt', '.md', '.py', '.json', '.csv']

# --- Application Info ---
APP_VERSION = "1.0.0"

# --- Logging ---
# These are base filenames; logger.py will join them with LOGS_DIR_PATH
CORE_AI_LOG_FILENAME = "puffin_ai_core.log"
CLI_LOG_FILENAME = "puffin_cli_interactions.log"
GUI_LAUNCH_LOG_FILENAME = "puffin_gui_launch.log"
APP_STATUS_LOG_FILENAME = "puffin_app_status.log" # For general CLI/App startup messages
DEFAULT_LOG_LEVEL = "INFO"
LOG_MAX_BYTES = 5 * 1024 * 1024  # 5 MB
LOG_BACKUP_COUNT = 3

def ensure_dirs():
    """Creates essential directories if they don't exist."""
    dirs_to_create = [DATA_DIR, MODELS_DIR, LOGS_DIR_PATH]
    for d in dirs_to_create:
        if not os.path.exists(d):
            try:
                os.makedirs(d, exist_ok=True)
                # print(f"Created directory: {d}") # Optional: for first run confirmation
            except OSError as e:
                # This print is important because if these dirs can't be made, parts of the app might fail.
                print(f"WARNING: Could not create directory {d}: {e}")

ensure_dirs() # Call this once when the config module is loaded

if __name__ == '__main__':
    print(f"Project Root Directory: {PROJECT_ROOT_DIR}")
    print(f"Default Model File Path: {MODEL_FILE_DEFAULT}")
    print(f"Models Directory: {MODELS_DIR}")
    print(f"Logs Directory: {LOGS_DIR_PATH}")
    print(f"Default Length Thresholds: {DEFAULT_LEN_THRESHOLDS}")
    print(f"Compressed File Suffix: {COMPRESSED_FILE_SUFFIX}")
    print(f"App Version: {APP_VERSION}")
    print(f"Default Batch Compress Extensions: {DEFAULT_BATCH_COMPRESS_EXTENSIONS}")