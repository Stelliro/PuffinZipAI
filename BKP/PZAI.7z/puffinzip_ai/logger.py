# PuffinZipAI_Project/puffinzip_ai/logger.py
import logging
import os
from logging.handlers import RotatingFileHandler
import sys  # Import the sys module

try:
    from .config import LOGS_DIR_PATH, CORE_AI_LOG_FILENAME, DEFAULT_LOG_LEVEL, LOG_MAX_BYTES, LOG_BACKUP_COUNT

    # Convert string log level from config to logging constant
    LOG_LEVEL_NAME = DEFAULT_LOG_LEVEL.upper()
    LOG_LEVEL_ACTUAL = getattr(logging, LOG_LEVEL_NAME, logging.INFO)
except ImportError:
    print("Warning: Could not import from config for logger.py. Using hardcoded defaults.")
    LOGS_DIR_PATH = "logs"
    CORE_AI_LOG_FILENAME = "puffin_ai_core.log"
    LOG_LEVEL_ACTUAL = logging.INFO
    LOG_MAX_BYTES = 5 * 1024 * 1024
    LOG_BACKUP_COUNT = 3
    # To avoid NameError for LOG_MAIN_DIR if config fails to import
    # We need LOGS_DIR_PATH defined here if not from config for standalone testing of this file.
    if 'LOG_MAIN_DIR' not in globals():  # Check if it wasn't set by a partial config import
        LOG_MAIN_DIR = "logs"  # Define a fallback
        if not os.path.exists(LOG_MAIN_DIR):
            try:
                os.makedirs(LOG_MAIN_DIR)
            except OSError:
                LOG_MAIN_DIR = "."  # Ultimate fallback


def setup_logger(logger_name='PuffinZipAI_Default',
                 log_filename=None,
                 log_level=None,
                 log_to_console=False,
                 console_level=None,  # Changed default to None
                 max_bytes=None,
                 backup_count=None,
                 log_formatter_str='%(asctime)s - %(name)s - %(levelname)s - %(module)s.%(funcName)s:%(lineno)d - %(message)s',
                 date_format_str='%Y-%m-%d %H:%M:%S'):
    logger = logging.getLogger(logger_name)

    effective_log_level = log_level if log_level is not None else LOG_LEVEL_ACTUAL
    effective_console_level = console_level if console_level is not None else effective_log_level  # Default console to file level if not specified
    effective_max_bytes = max_bytes if max_bytes is not None else LOG_MAX_BYTES
    effective_backup_count = backup_count if backup_count is not None else LOG_BACKUP_COUNT

    if not logger.handlers:
        logger.setLevel(min(effective_log_level, effective_console_level) if log_to_console else effective_log_level)
        log_formatter = logging.Formatter(log_formatter_str, datefmt=date_format_str)

        default_filename_for_logger = CORE_AI_LOG_FILENAME if logger_name == 'PuffinZipAI_Core' else f"{logger_name.lower().replace(' ', '_')}.log"
        chosen_log_filename = log_filename if log_filename is not None else default_filename_for_logger

        if os.path.isabs(chosen_log_filename):
            final_log_path = chosen_log_filename
        else:
            final_log_path = os.path.join(LOGS_DIR_PATH, chosen_log_filename)

        log_file_dir = os.path.dirname(final_log_path)
        if log_file_dir and not os.path.exists(log_file_dir):
            try:
                os.makedirs(log_file_dir, exist_ok=True)
            except OSError as e:
                print(
                    f"Warning: Could not create log directory '{log_file_dir}' for {logger_name}. Logging to current dir: {os.path.basename(final_log_path)}. Error: {e}")
                final_log_path = os.path.basename(final_log_path)

        try:
            fh = RotatingFileHandler(final_log_path, maxBytes=effective_max_bytes, backupCount=effective_backup_count,
                                     encoding='utf-8')
            fh.setLevel(effective_log_level)
            fh.setFormatter(log_formatter)
            logger.addHandler(fh)
        except Exception as e:
            print(f"ERROR: Failed to set up file logging for '{logger_name}' at '{final_log_path}'. Reason: {e}")
            log_to_console = True
            effective_console_level = effective_log_level

        if log_to_console:
            ch = logging.StreamHandler(sys.stdout)  # Use sys.stdout
            ch.setLevel(effective_console_level)
            ch.setFormatter(log_formatter)
            logger.addHandler(ch)

        if not logger.handlers:
            print(f"WARNING: Logger '{logger_name}' has no handlers. Using basic stderr.")
            fallback_handler = logging.StreamHandler(sys.stderr)
            fallback_handler.setFormatter(log_formatter)
            logger.addHandler(fallback_handler)
            logger.setLevel(logging.WARNING)
            logger.warning(f"Logger '{logger_name}' had no handlers; added fallback stderr handler.")
    else:  # Handlers exist, potentially update levels
        new_overall_level = min(effective_log_level, effective_console_level) if log_to_console else effective_log_level
        if logger.level != new_overall_level:
            logger.setLevel(new_overall_level)

        for handler in logger.handlers:
            if isinstance(handler, RotatingFileHandler) and handler.level != effective_log_level:
                handler.setLevel(effective_log_level)
            elif isinstance(handler,
                            logging.StreamHandler):  # This includes StreamHandler(sys.stdout) or StreamHandler(sys.stderr)
                new_ch_level = effective_console_level if log_to_console else logging.CRITICAL + 1  # Effectively disable if log_to_console is False
                if handler.level != new_ch_level:
                    handler.setLevel(new_ch_level)
        # logger.info(f"Levels re-evaluated for existing logger '{logger_name}'.") # Can be noisy

    return logger


if __name__ == '__main__':
    print(f"--- Testing logger.py (will try to create log files in '{LOGS_DIR_PATH}') ---")

    if not os.path.exists(LOGS_DIR_PATH):  # Ensure LOGS_DIR_PATH is used
        try:
            os.makedirs(LOGS_DIR_PATH, exist_ok=True)
            print(f"Created directory for test: {LOGS_DIR_PATH}")
        except OSError as e:
            print(f"Could not create log directory {LOGS_DIR_PATH}: {e}. Logs will be in current dir.")
            LOGS_DIR_PATH = "."

    logger1 = setup_logger("TestLogger1", log_filename="test1.log", log_level=logging.DEBUG, log_to_console=True,
                           console_level=logging.INFO)
    logger1.debug("This is a debug message for TestLogger1 (file only unless console_level=DEBUG).")
    logger1.info("This is an info message for TestLogger1 (file and console).")

    core_logger_test = setup_logger("PuffinZipAI_Core", log_to_console=True, console_level=logging.DEBUG)
    core_logger_test.info("Core logger test info.")
    core_logger_test.debug("Core logger test debug.")

    app_status_logger = setup_logger("PuffinZipAI_AppMain", log_level=logging.INFO, log_to_console=True)
    app_status_logger.info("AppStatus logger initialized for testing.")

    print(
        f"\nLog files should be in the '{os.path.abspath(LOGS_DIR_PATH)}' directory or current directory if creation failed.")