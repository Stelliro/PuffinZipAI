# PuffinZipAI_Project/puffinzip_gui/main_app.py

import tkinter as tk
from tkinter import ttk, filedialog, scrolledtext, messagebox
import threading
import queue
import os
import traceback
import time
import sys

try:
    from puffinzip_ai import (
        PuffinZipAI, MODEL_FILE_DEFAULT, COMPRESSED_FILE_SUFFIX, DEFAULT_BATCH_COMPRESS_EXTENSIONS
    )

    try:
        from puffinzip_ai.ai_core import DummyLogger
    except ImportError:
        class DummyLogger:
            pass
except ImportError as e:
    fallback_log_path = "gui_critical_import_error.log"
    with open(fallback_log_path, "a") as f_err:
        f_err.write(f"{time.strftime('%Y-%m-%d %H:%M:%S')}\nIMPORT FAIL: {e}\n{traceback.format_exc()}\n\n")
    try:
        root_err = tk.Tk();
        root_err.withdraw()
        messagebox.showerror("Fatal Import Error",
                             f"Core AI components missing: {e}\nApp cannot start. See {os.path.abspath(fallback_log_path)}")
        root_err.destroy()
    except Exception:
        print(f"FATAL ERROR: Could not import core AI components: {e}. Details in {os.path.abspath(fallback_log_path)}")
    sys.exit(1)

BG_COLOR = "#2E2E2E";
FG_COLOR = "#FFFFFF";
BUTTON_BG = "#4A4A4A";
BUTTON_FG = FG_COLOR
INPUT_BG = "#3C3C3C";
INPUT_FG = FG_COLOR;
ACCENT_COLOR = "#007ACC";
TEXT_AREA_BG = "#1E1E1E"
TEXT_AREA_FG = "#D0D0D0";
LABEL_FG = "#C0C0C0";
FRAME_BG = "#383838"
SCROLLBAR_TROUGH = "#3C3C3C";
SCROLLBAR_BG = "#5A5A5A";
TAB_BG = "#252526";
ACTIVE_TAB_BG = FRAME_BG


class PuffinZipApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("PuffinZipAI Control Panel");
        self.geometry("1000x700");
        self.minsize(800, 600);
        self.configure(bg=BG_COLOR)
        self.ai_agent = None
        try:
            self.ai_agent = PuffinZipAI()
        except Exception as e_ai_init:
            self._handle_critical_error(f"PuffinZipAI agent init failed: {e_ai_init}", e_ai_init);return

        self.gui_output_queue = queue.Queue();
        self.gui_stop_event = threading.Event()
        if self.ai_agent:
            self.ai_agent.gui_output_queue = self.gui_output_queue;
            self.ai_agent.gui_stop_event = self.gui_stop_event

        self.current_task_thread = None;
        self.task_running = False

        self._setup_styles();
        self._setup_main_layout();
        self._populate_main_tab_controls(self.main_controls_tab_scrollable_frame)
        self._populate_analysis_tab(self.analysis_tab)

        self.log_message("GUI Initialized. Loading default model...")
        if self.ai_agent and self.ai_agent.load_model(): pass
        if self.ai_agent:
            self.thresholds_entry.delete(0, tk.END);
            self.thresholds_entry.insert(0, ",".join(map(str, self.ai_agent.len_thresholds)))

        self.process_gui_queue();
        self.protocol("WM_DELETE_WINDOW", self.on_closing)

    def _handle_critical_error(self, user_message, exception_obj=None):
        tb_info = traceback.format_exc() if exception_obj else "No exception object provided."
        log_path = "gui_critical_runtime_error.log"
        with open(log_path, "a") as f:
            f.write(f"{time.strftime('%Y-%m-%d %H:%M:%S')}\n{user_message}\n{tb_info}\n\n")
        if self.winfo_exists(): messagebox.showerror("Critical Error",
                                                     f"{user_message}\nCheck {os.path.abspath(log_path)} for details.",
                                                     parent=self)
        if self.winfo_exists(): self.destroy()

    def _setup_styles(self):
        s = ttk.Style(self);
        s.theme_use('clam')
        s.configure("TFrame", background=FRAME_BG);
        s.configure("Scrollable.TFrame", background=FRAME_BG)
        s.configure("Accent.TLabel", background=FRAME_BG, foreground=ACCENT_COLOR, font=('Arial', 11, 'bold'),
                    padding=(2, 0))
        s.configure("TLabel", background=FRAME_BG, foreground=LABEL_FG, padding=3, font=('Arial', 10))
        s.configure("TButton", background=BUTTON_BG, foreground=BUTTON_FG, padding=(5, 3), font=('Arial', 10, 'bold'))
        s.map("TButton", background=[('active', ACCENT_COLOR), ('pressed', ACCENT_COLOR), ('!disabled', BUTTON_BG)],
              foreground=[('active', FG_COLOR), ('!disabled', BUTTON_FG), ('disabled', LABEL_FG)],
              relief=[('pressed', 'sunken'), ('!pressed', 'raised')])
        s.configure("TEntry", fieldbackground=INPUT_BG, foreground=INPUT_FG, insertbackground=FG_COLOR, borderwidth=1,
                    relief="solid", padding=2)
        s.configure("TCheckbutton", background=FRAME_BG, foreground=LABEL_FG, font=('Arial', 10));
        s.map("TCheckbutton", background=[('active', FRAME_BG)],
              indicatorcolor=[('selected', ACCENT_COLOR), ('!selected', INPUT_BG)])
        s.configure("Vertical.TScrollbar", troughcolor=SCROLLBAR_TROUGH, background=SCROLLBAR_BG, bordercolor=FRAME_BG,
                    arrowcolor=FG_COLOR);
        s.map("Vertical.TScrollbar", background=[('pressed', ACCENT_COLOR), ('active', ACCENT_COLOR)])
        s.configure("TNotebook", background=BG_COLOR, tabmargins=[2, 5, 2, 0])
        s.configure("TNotebook.Tab", background=TAB_BG, foreground=LABEL_FG, padding=[10, 5],
                    font=('Arial', 10, 'bold'))
        s.map("TNotebook.Tab", background=[("selected", ACTIVE_TAB_BG)], foreground=[("selected", ACCENT_COLOR)])

    def _setup_main_layout(self):
        notebook = ttk.Notebook(self, style="TNotebook")
        self.main_controls_tab = ttk.Frame(notebook, style="TFrame")
        self.analysis_tab = ttk.Frame(notebook, style="TFrame")
        notebook.add(self.main_controls_tab, text='Main Controls');
        notebook.add(self.analysis_tab, text='Analysis & Stats')
        notebook.pack(expand=True, fill='both')

        main_left_panel = ttk.Frame(self.main_controls_tab, width=380)
        main_left_panel.pack(side=tk.LEFT, fill=tk.Y, padx=(10, 5), pady=10);
        main_left_panel.pack_propagate(False)
        self.ctrl_canvas = tk.Canvas(main_left_panel, bg=FRAME_BG, highlightthickness=0);
        self.ctrl_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scr_b = ttk.Scrollbar(main_left_panel, orient=tk.VERTICAL, command=self.ctrl_canvas.yview,
                              style="Vertical.TScrollbar");
        scr_b.pack(side=tk.RIGHT, fill=tk.Y)
        self.ctrl_canvas.configure(yscrollcommand=scr_b.set);
        self.main_controls_tab_scrollable_frame = ttk.Frame(self.ctrl_canvas, style="Scrollable.TFrame")
        self.cv_fid = self.ctrl_canvas.create_window((0, 0), window=self.main_controls_tab_scrollable_frame,
                                                     anchor="nw")
        self.main_controls_tab_scrollable_frame.bind("<Configure>", self.on_frame_configure, add="+");
        self.ctrl_canvas.bind("<Configure>", self.on_canvas_configure, add="+")

        main_right_panel = ttk.Frame(self.main_controls_tab)
        main_right_panel.pack(side=tk.RIGHT, expand=True, fill=tk.BOTH, padx=(5, 10), pady=10)
        self.output_scrolled_text = scrolledtext.ScrolledText(main_right_panel, wrap=tk.WORD, bg=TEXT_AREA_BG,
                                                              fg=TEXT_AREA_FG, insertbackground=FG_COLOR,
                                                              font=('Consolas', 10), borderwidth=1, relief="solid",
                                                              undo=True)
        self.output_scrolled_text.pack(expand=True, fill=tk.BOTH);
        self.output_scrolled_text.configure(state='disabled')

        analysis_label = ttk.Label(self.analysis_tab, text="Analysis charts and statistics.", style="TLabel",
                                   font=('Arial', 14, 'italic'))
        analysis_label.pack(padx=20, pady=20, expand=False, anchor="n")
        self.chart_placeholder_frame = ttk.Frame(self.analysis_tab, style="TFrame", relief="sunken", borderwidth=1)
        self.chart_placeholder_frame.pack(padx=20, pady=10, expand=True, fill="both")
        ttk.Label(self.chart_placeholder_frame, text="Chart Area (Connect to chart_utils.py)",
                  font=('Arial', 10, 'italic')).pack(padx=5, pady=5, anchor="center")

    def _populate_main_tab_controls(self, p):
        self._create_training_section(p);
        self._create_batch_ops_section(p);
        self._create_single_item_section(p);
        self._create_model_config_section(p);
        self._create_utility_section(p)
        self.stop_action_button = ttk.Button(p, text="Stop Current Task", command=self.request_task_stop,
                                             state=tk.DISABLED);
        self.stop_action_button.pack(pady=15, fill=tk.X, padx=10)

    def _populate_analysis_tab(self, parent_tab_frame):
        refresh_button = ttk.Button(parent_tab_frame, text="Refresh Analysis Data", command=self.refresh_analysis_data)
        refresh_button.pack(pady=10, side="top")

    def refresh_analysis_data(self):
        self.log_message("Analysis data refresh requested...")
        if not self._is_ai_agent_ready(): return
        stats = self.ai_agent.training_stats
        self.log_message(
            f"Stats:TotalItems:{stats.get('total_items_processed', 0)},AvgRwd:{(stats.get('cumulative_reward', 0) / (stats.get('total_items_processed', 1) if stats.get('total_items_processed', 0) > 0 else 1)):.3f},DecompErrs:{stats.get('decomp_errors', 0)}")
        self.log_message(
            f"RLEChosen:{stats.get('rle_chosen_count', 0)},NoCompChosen:{stats.get('nocomp_chosen_count', 0)}")
        try:
            from .chart_utils import plot_training_rewards, plot_action_distribution

            # Example data structures (AI agent should provide these)
            # reward_history = self.ai_agent.training_stats.get('reward_history_for_plot', [])
            reward_history_placeholder = [random.uniform(0.5, 3.0) for _ in range(
                self.ai_agent.training_stats.get('total_items_processed', 50) // 1000 or 10)]  # Dummy data
            if not reward_history_placeholder and self.ai_agent.training_stats.get('total_items_processed',
                                                                                   0) > 0:  # Ensure some data if items processed
                reward_history_placeholder = [
                    self.ai_agent.training_stats.get('cumulative_reward', 0) / self.ai_agent.training_stats.get(
                        'total_items_processed', 1)]

            action_dist_data = {
                "RLE": self.ai_agent.training_stats.get('rle_chosen_count', 0),
                "NoComp": self.ai_agent.training_stats.get('nocomp_chosen_count', 0)
            }
            plot_action_distribution(self.chart_placeholder_frame,
                                     action_dist_data)  # This might create a second chart if not cleared properly
            # If chart_utils clears frame, then plot_training_rewards(self.chart_placeholder_frame, reward_history_placeholder) here.
            # For now, one chart placeholder, will be overwritten.

        except ImportError:
            self.log_message("ERROR: chart_utils.py or matplotlib not found.")
        except Exception as e_chart:
            self.log_message(f"ERROR plotting charts: {e_chart}")
        self.log_message("Chart display attempt (placeholder).")

    def on_frame_configure(self, e=None):
        self.ctrl_canvas.configure(scrollregion=self.ctrl_canvas.bbox("all"))

    def on_canvas_configure(self, e=None):
        self.ctrl_canvas.itemconfig(self.cv_fid, width=e.width)

    def _create_gui_frame(self, p, t):
        f = ttk.LabelFrame(p, text=t, padding="10 10 10 10");f.pack(fill=tk.X, padx=10, pady=(5, 10));f.configure(
            style="TFrame");f.config(labelwidget=ttk.Label(f, text=t, style="Accent.TLabel"));return f

    def _add_labeled_entry_with_browse(self, p, lbl, r):
        ttk.Label(p, text=lbl).grid(row=r, column=0, columnspan=2, sticky=tk.W, pady=(0, 2));e = ttk.Entry(p);e.grid(
            row=r + 1, column=0, sticky=tk.EW, pady=(0, 2));ttk.Button(p, text="Browse",
                                                                       command=lambda et=e: self.browse_folder(
                                                                           et)).grid(row=r + 1, column=1, padx=5,
                                                                                     sticky="ew");p.grid_columnconfigure(
            0, weight=1);return e

    def _create_training_section(self, p):
        f = self._create_gui_frame(p, "AI Training")
        ttk.Label(f, text="Episodes (or 'c'):").grid(row=0, column=0, sticky=tk.W);
        self.random_episodes_entry = ttk.Entry(f, width=12);
        self.random_episodes_entry.insert(0, "1000");
        self.random_episodes_entry.grid(row=0, column=1, sticky=tk.EW, padx=(0, 5))
        ttk.Label(f, text="Batch Size:").grid(row=1, column=0, sticky=tk.W);
        self.random_batch_entry = ttk.Entry(f, width=12);
        self.random_batch_entry.insert(0, "10");
        self.random_batch_entry.grid(row=1, column=1, sticky=tk.EW, padx=(0, 5))
        ttk.Button(f, text="Train (Random)", command=self.start_random_training).grid(row=0, column=2, rowspan=2,
                                                                                      padx=5, sticky="nsew")
        ttk.Separator(f, orient=tk.HORIZONTAL).grid(row=2, column=0, columnspan=3, sticky="ew", pady=8)
        self.folder_learn_path_entry = self._add_labeled_entry_with_browse(f, "Learn from Folder:", 3)
        ttk.Label(f, text="Exts (.txt,.log):").grid(row=5, column=0, sticky=tk.W);
        self.folder_learn_ext_entry = ttk.Entry(f);
        self.folder_learn_ext_entry.insert(0, ".txt");
        self.folder_learn_ext_entry.grid(row=5, column=1, sticky=tk.EW, padx=(0, 5))
        ttk.Label(f, text="Batch Size:").grid(row=6, column=0, sticky=tk.W);
        self.folder_learn_batch_entry = ttk.Entry(f);
        self.folder_learn_batch_entry.insert(0, "1");
        self.folder_learn_batch_entry.grid(row=6, column=1, sticky=tk.EW, padx=(0, 5))
        self.folder_learn_continuous_var = tk.BooleanVar();
        ttk.Checkbutton(f, text="Continuous", variable=self.folder_learn_continuous_var, style="TCheckbutton").grid(
            row=5, column=2, rowspan=2, sticky=tk.W, padx=5)
        ttk.Button(f, text="Train (Folder)", command=self.start_folder_learning).grid(row=7, column=0, columnspan=3,
                                                                                      pady=(5, 0), sticky=tk.EW)
        f.grid_columnconfigure(1, weight=1)

    def _create_batch_ops_section(self, p):
        f = self._create_gui_frame(p, "Batch Operations")
        self.compress_input_folder_entry = self._add_labeled_entry_with_browse(f, "Input Folder (Compress):", 0)
        self.compress_output_folder_entry = self._add_labeled_entry_with_browse(f, "Output Folder (Compress):", 2)
        ttk.Label(f, text="Source Exts:").grid(row=4, column=0, sticky=tk.W);
        self.compress_ext_entry = ttk.Entry(f);
        self.compress_ext_entry.insert(0, ",".join(DEFAULT_BATCH_COMPRESS_EXTENSIONS));
        self.compress_ext_entry.grid(row=4, column=0, sticky=tk.EW, pady=(0, 5), columnspan=2)
        ttk.Button(f, text="Batch Compress", command=self.start_batch_compress).grid(row=5, column=0, columnspan=2,
                                                                                     pady=(0, 5), sticky=tk.EW)
        ttk.Separator(f, orient=tk.HORIZONTAL).grid(row=6, column=0, columnspan=2, sticky="ew", pady=8)
        self.decompress_input_folder_entry = self._add_labeled_entry_with_browse(f, "Input Folder (Decompress):", 7)
        self.decompress_output_folder_entry = self._add_labeled_entry_with_browse(f, "Output Folder (Decompress):", 9)
        ttk.Button(f, text="Batch Decompress", command=self.start_batch_decompress).grid(row=11, column=0, columnspan=2,
                                                                                         pady=5, sticky=tk.EW)

    def _create_single_item_section(self, p):
        f = self._create_gui_frame(p, "Single Item Processing");
        ttk.Label(f, text="Text Item:").pack(anchor=tk.W)
        self.item_text_entry = ttk.Entry(f, width=40);
        self.item_text_entry.pack(fill=tk.X, pady=(0, 5))
        bf = ttk.Frame(f);
        bf.pack(fill=tk.X)
        ttk.Button(bf, text="Compress (AI)", command=self.compress_single_item).pack(side=tk.LEFT, expand=True,
                                                                                     fill=tk.X, padx=(0, 2))
        ttk.Button(bf, text="Decompress (RLE)", command=self.decompress_single_item).pack(side=tk.LEFT, expand=True,
                                                                                          fill=tk.X, padx=(2, 0))

    def _create_model_config_section(self, p):
        f = self._create_gui_frame(p, "Model & Configuration")
        ttk.Label(f, text="Length Thresh:").grid(row=0, column=0, sticky=tk.W);
        self.thresholds_entry = ttk.Entry(f);
        self.thresholds_entry.grid(row=0, column=1, sticky=tk.EW, pady=(0, 5), padx=(0, 5))
        ttk.Button(f, text="Configure Model", command=self.configure_categories).grid(row=0, column=2, padx=5,
                                                                                      sticky="ew")
        ttk.Button(f, text="View Q-Table", command=self.display_q_table).grid(row=1, column=0, columnspan=3, pady=2,
                                                                              sticky=tk.EW)
        ttk.Label(f, text="Test AI Items:").grid(row=2, column=0, sticky=tk.W);
        self.test_items_entry = ttk.Entry(f, width=7);
        self.test_items_entry.insert(0, "5");
        self.test_items_entry.grid(row=2, column=1, sticky=tk.W, pady=(0, 5), padx=(0, 5))
        ttk.Button(f, text="Test AI", command=self.test_ai).grid(row=2, column=2, padx=5, sticky="ew")
        f.grid_columnconfigure(1, weight=1)

    def _create_utility_section(self, p):
        f = self._create_gui_frame(p, "Utilities");
        bf = ttk.Frame(f);
        bf.pack(fill=tk.X)
        ttk.Button(bf, text="Load Model", command=self.load_model).pack(side=tk.LEFT, expand=True, fill=tk.X,
                                                                        padx=(0, 2))
        ttk.Button(bf, text="Save Model", command=self.save_model).pack(side=tk.LEFT, expand=True, fill=tk.X,
                                                                        padx=(2, 0))

    def log_message(self, msg):
        if not hasattr(self, 'output_scrolled_text') or not self.output_scrolled_text.winfo_exists(): return
        if not isinstance(msg, str): msg = str(msg)
        self.output_scrolled_text.configure(state='normal');
        self.output_scrolled_text.insert(tk.END, msg + ("\n" if not msg.endswith("\n") else ""));
        self.output_scrolled_text.see(tk.END);
        self.output_scrolled_text.configure(state='disabled');
        self.update_idletasks()

    def process_gui_queue(self):
        try:
            while True: self.log_message(self.gui_output_queue.get_nowait())
        except queue.Empty:
            pass
        finally:
            if self.winfo_exists(): self.after(100, self.process_gui_queue)

    def browse_folder(self, entry_w):
        folder = filedialog.askdirectory(parent=self); (entry_w.delete(0, tk.END),
                                                        entry_w.insert(0, folder)) if folder else None

    def _is_ai_agent_ready(self):
        if not self.ai_agent: self.log_message("ERROR: AI Agent unavailable.");messagebox.showerror("AI Error",
                                                                                                    "AI Agent not initialized.",
                                                                                                    parent=self);return False
        return True

    def _start_ai_task(self, ai_method_to_call, *args_for_ai_method, **kwargs_for_ai_method):
        if not self._is_ai_agent_ready(): return
        if self.task_running: messagebox.showwarning("Task Busy", "Another task is currently running.",
                                                     parent=self);return

        self.gui_stop_event.clear();
        self.task_running = True
        self.after(0, lambda: self.stop_action_button.config(state=tk.NORMAL))

        thread_target_kwargs = {'actual_ai_method': ai_method_to_call, 'method_args': args_for_ai_method,
                                'method_kwargs': kwargs_for_ai_method}
        self.current_task_thread = threading.Thread(target=self._ai_task_thread_wrapper, kwargs=thread_target_kwargs,
                                                    daemon=True)
        self.current_task_thread.start()

    def _ai_task_thread_wrapper(self, actual_ai_method, method_args, method_kwargs):
        name = actual_ai_method.__name__ if hasattr(actual_ai_method, '__name__') else "AI_SubTask"
        if self.winfo_exists(): self.after(0, lambda: self.log_message(f"--- Task Started ({name}) ---"))
        try:
            actual_ai_method(*method_args, **method_kwargs)
        except Exception as task_exc:
            err_msg = f"ERROR in task ({name}): {type(task_exc).__name__}: {task_exc}"
            if self.winfo_exists():
                self.after(0, lambda m=err_msg: self.gui_output_queue.put(m))
            else:
                self.gui_output_queue.put(err_msg)

            tb_fmt = traceback.format_exc();
            print(f"GUI Task Exception ({name}):\n{tb_fmt}")
            if hasattr(self.ai_agent, 'logger') and not isinstance(self.ai_agent.logger, DummyLogger):
                self.ai_agent.logger.error(f"GUI Task Wrapper ({name}) caught exception:\n{tb_fmt}")
        finally:
            self.task_running = False
            if self.winfo_exists():
                self.after(0, lambda: self.stop_action_button.config(state=tk.DISABLED))
                self.after(0, lambda: self.log_message(f"--- Task Finished ({name}) ---"))

    def request_task_stop(self):
        if self.task_running and self.current_task_thread and self.current_task_thread.is_alive():
            self.log_message("Stop signal sent... Waiting for task acknowledgment.")
            self.gui_stop_event.set()
            self.stop_action_button.config(state=tk.DISABLED)
        else:
            self.log_message("No stoppable task running.");
            self.stop_action_button.config(state=tk.DISABLED)

    def start_random_training(self):
        if not self._is_ai_agent_ready(): return
        eps_s = self.random_episodes_entry.get().strip().lower();
        batch_s = self.random_batch_entry.get().strip()
        try:
            b_size = max(1, int(batch_s))
        except ValueError:
            self.log_message(f"Invalid batch:'{batch_s}'.Default 1.");b_size = 1

        if eps_s == 'c':
            self._start_ai_task(self.ai_agent.train, run_continuously=True, batch_size=b_size)
        else:
            try:
                num_e = int(eps_s)
                if num_e > 0:
                    self._start_ai_task(self.ai_agent.train, num_episodes=num_e, batch_size=b_size)
                else:
                    self.log_message("Episodes must be > 0.")
            except ValueError:
                self.log_message(f"Invalid episodes:'{eps_s}'.Use number or 'c'.")

    def start_folder_learning(self):
        if not self._is_ai_agent_ready(): return
        f_p = self.folder_learn_path_entry.get().strip()
        if not os.path.isdir(f_p): self.log_message(f"Error: Folder '{f_p}' not found.");return
        try:
            b_size = max(1, int(self.folder_learn_batch_entry.get().strip()))
        except ValueError:
            self.log_message("Invalid batch for folder.Default 1.");b_size = 1
        cont = self.folder_learn_continuous_var.get();
        exts_s = self.folder_learn_ext_entry.get().strip().lower()
        exts = [e.strip() for e in exts_s.split(',') if e.strip().startswith('.')] if exts_s else ['.txt']
        if not exts: exts = ['.txt']
        self._start_ai_task(self.ai_agent.learn_from_folder, f_p, allowed_extensions=exts, run_continuously=cont,
                            batch_size=b_size)

    def start_batch_compress(self):
        if not self._is_ai_agent_ready(): return
        in_f, out_f = self.compress_input_folder_entry.get().strip(), self.compress_output_folder_entry.get().strip()
        if not in_f or not out_f: self.log_message("In/Out folders required.");return
        if in_f == out_f: self.log_message("In/Out folders must differ.");return
        exts_s = self.compress_ext_entry.get().strip().lower();
        def_exts = DEFAULT_BATCH_COMPRESS_EXTENSIONS
        exts = [e.strip() for e in exts_s.split(',') if e.strip().startswith('.')] if exts_s else def_exts
        if not exts: exts = def_exts
        self._start_ai_task(self.ai_agent.batch_compress_folder, in_f, out_f, allowed_extensions=exts)

    def start_batch_decompress(self):
        if not self._is_ai_agent_ready(): return
        in_f, out_f = self.decompress_input_folder_entry.get().strip(), self.decompress_output_folder_entry.get().strip()
        if not in_f or not out_f: self.log_message("In/Out folders required.");return
        if in_f == out_f: self.log_message("In/Out folders must differ.");return
        self._start_ai_task(self.ai_agent.batch_decompress_folder, in_f, out_f)

    def compress_single_item(self):
        if not self._is_ai_agent_ready(): return
        item = self.item_text_entry.get();
        (self.ai_agent.compress_user_item(item) if item else self.log_message("Enter text to compress."))

    def decompress_single_item(self):
        if not self._is_ai_agent_ready(): return
        item = self.item_text_entry.get();
        (self.ai_agent.decompress_user_item_rle(item) if item else self.log_message("Enter RLE text to decompress."))

    def display_q_table(self):
        if not self._is_ai_agent_ready(): return
        self.ai_agent.display_q_table_summary()

    def configure_categories(self):
        if not self._is_ai_agent_ready(): return
        thresh_s = self.thresholds_entry.get()
        if self.ai_agent.configure_data_categories(thresh_s.split(',')):
            self.thresholds_entry.delete(0, tk.END);
            self.thresholds_entry.insert(0, ",".join(map(str, self.ai_agent.len_thresholds)))

    def test_ai(self):
        if not self._is_ai_agent_ready(): return
        items_str = self.test_items_entry.get().strip()
        try:
            num_items = int(items_str)
            if num_items <= 0: self.log_message("Test items must be > 0."); return
            self._start_ai_task(self.ai_agent.test_agent_on_random_items, num_items)
        except ValueError:
            self.log_message(f"Invalid number for test items: '{items_str}'.")

    def save_model(self):
        if not self._is_ai_agent_ready(): return
        fp = filedialog.asksaveasfilename(defaultextension=".dat", initialfile=MODEL_FILE_DEFAULT, title="Save Model",
                                          parent=self)
        if fp: self.ai_agent.save_model(fp)

    def load_model(self):
        if not self._is_ai_agent_ready(): return
        fp = filedialog.askopenfilename(defaultextension=".dat", initialfile=MODEL_FILE_DEFAULT, title="Load Model",
                                        parent=self)
        if fp and self.ai_agent.load_model(fp):
            self.thresholds_entry.delete(0, tk.END);
            self.thresholds_entry.insert(0, ",".join(map(str, self.ai_agent.len_thresholds)))

    def on_closing(self):
        can_close = True
        if self.task_running and self.current_task_thread and self.current_task_thread.is_alive():
            if messagebox.askokcancel("Quit", "Task running. Stop & Exit?", parent=self):
                self.request_task_stop();
                self.log_message("Exit req. Sent stop signal. Window will close shortly.")
                self.after(500, self.destroy_if_safe)
                can_close = False
            else:
                can_close = False
        if can_close: self.destroy_if_safe(force_quit_dialog=True)

    def destroy_if_safe(self, force_quit_dialog=False):
        if self.task_running and self.current_task_thread and self.current_task_thread.is_alive():
            if messagebox.askretrycancel("Task Still Running", "Background task still active. Retry closing or cancel?",
                                         parent=self):
                self.after(1000, self.destroy_if_safe)
            return
        if force_quit_dialog:
            if not messagebox.askokcancel("Quit", "Quit PuffinZipAI?", parent=self): return
        self.log_message("Exiting PuffinZipAI GUI.")
        if self.ai_agent and hasattr(self.ai_agent, 'logger') and not isinstance(self.ai_agent.logger, DummyLogger):
            self.ai_agent.logger.info("PuffinZipAI GUI closed by user.")
        super().destroy()