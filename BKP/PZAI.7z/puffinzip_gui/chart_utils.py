# PuffinZipAI_Project/puffinzip_gui/chart_utils.py

import tkinter as tk
from tkinter import ttk  # For potential styling or framing if needed


# import matplotlib.pyplot as plt # Import when you have data to plot
# from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg # For embedding in Tkinter

# This will be populated with functions to create and update charts.
# For now, it's a placeholder structure.

# --- Placeholder for Chart Data Handling ---
# In a real implementation, PuffinZipAI would likely expose methods
# to retrieve historical training data (e.g., rewards per episode,
# action distribution over time, etc.)

# Global or class variables to hold figure and canvas if needed for updates
# chart_figure = None
# chart_canvas_widget = None

def clear_frame(frame: tk.Frame):
    for widget in frame.winfo_children():
        widget.destroy()


def display_placeholder_chart(parent_frame: tk.Frame, message: str = "Chart Area - Awaiting Data/Implementation"):
    clear_frame(parent_frame)
    placeholder_label = ttk.Label(parent_frame, text=message, style="TLabel", font=('Arial', 12, 'italic'),
                                  anchor="center")
    placeholder_label.pack(expand=True, fill="both", padx=10, pady=10)


def plot_training_rewards(parent_frame: tk.Frame, rewards_history: list):
    """
    Placeholder function to demonstrate where Matplotlib plotting would go.
    Requires Matplotlib to be installed and correctly configured for Tkinter.
    """
    clear_frame(parent_frame)

    if not rewards_history:
        display_placeholder_chart(parent_frame, "No reward data available to plot.")
        return

    # --- This is where Matplotlib integration would happen ---
    # Example (requires `pip install matplotlib`):
    try:
        import matplotlib.pyplot as plt
        from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

        fig = plt.figure.Figure(figsize=(6, 4), dpi=100)  # Use plt.figure.Figure for embedding
        fig.patch.set_facecolor(
            parent_frame.cget('background'))  # Match background if possible (might need to map FRAME_BG to hex)

        plot_axes = fig.add_subplot(111)
        plot_axes.plot(rewards_history, marker='o', linestyle='-', color='#007ACC')
        plot_axes.set_title("Reward per Episode/Batch (Placeholder)", color="#D0D0D0")
        plot_axes.set_xlabel("Episode/Batch", color="#C0C0C0")
        plot_axes.set_ylabel("Average Reward", color="#C0C0C0")
        plot_axes.tick_params(axis='x', colors='#C0C0C0')
        plot_axes.tick_params(axis='y', colors='#C0C0C0')
        plot_axes.grid(True, linestyle='--', alpha=0.5, color='#555555')
        plot_axes.set_facecolor("#252526")  # Dark background for plot area

        # Set color for spines (the lines forming the box of the plot)
        plot_axes.spines['bottom'].set_color('#888888')
        plot_axes.spines['top'].set_color('#888888')
        plot_axes.spines['right'].set_color('#888888')
        plot_axes.spines['left'].set_color('#888888')

        canvas = FigureCanvasTkAgg(fig, master=parent_frame)
        canvas_widget = canvas.get_tk_widget()
        canvas_widget.pack(side=tk.TOP, fill=tk.BOTH, expand=True)
        canvas.draw()

    except ImportError:
        display_placeholder_chart(parent_frame,
                                  "Matplotlib not found. Please install it to view charts.\n(pip install matplotlib)")
    except Exception as e:
        display_placeholder_chart(parent_frame, f"Error plotting chart: {e}")
        print(f"Plotting error: {e}\n{traceback.format_exc()}")


def plot_action_distribution(parent_frame: tk.Frame, action_counts: dict):
    """
    Placeholder for plotting RLE vs NoCompression action distribution.
    action_counts = {'RLE': count1, 'NoCompression': count2}
    """
    clear_frame(parent_frame)
    if not action_counts or not any(action_counts.values()):
        display_placeholder_chart(parent_frame, "No action data for distribution plot.")
        return

    try:
        import matplotlib.pyplot as plt
        from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

        labels = list(action_counts.keys())
        counts = list(action_counts.values())

        fig = plt.figure.Figure(figsize=(5, 4), dpi=100)
        fig.patch.set_facecolor(parent_frame.cget('background'))  # Match background

        plot_axes = fig.add_subplot(111)
        plot_axes.bar(labels, counts, color=['#007ACC', '#4A4A4A'])
        plot_axes.set_title("Action Distribution (Placeholder)", color="#D0D0D0")
        plot_axes.set_ylabel("Times Chosen", color="#C0C0C0")
        plot_axes.tick_params(axis='x', colors='#C0C0C0', rotation=0)  # Rotation for labels if needed
        plot_axes.tick_params(axis='y', colors='#C0C0C0')
        plot_axes.grid(True, axis='y', linestyle='--', alpha=0.5, color='#555555')
        plot_axes.set_facecolor("#252526")

        plot_axes.spines['bottom'].set_color('#888888')
        plot_axes.spines['top'].set_color('#888888')
        plot_axes.spines['right'].set_color('#888888')
        plot_axes.spines['left'].set_color('#888888')

        canvas = FigureCanvasTkAgg(fig, master=parent_frame)
        canvas_widget = canvas.get_tk_widget()
        canvas_widget.pack(side=tk.TOP, fill=tk.BOTH, expand=True)
        canvas.draw()

    except ImportError:
        display_placeholder_chart(parent_frame, "Matplotlib not found for action distribution chart.")
    except Exception as e:
        display_placeholder_chart(parent_frame, f"Error plotting action distribution: {e}")
        print(f"Plotting error (action dist): {e}\n{traceback.format_exc()}")


if __name__ == '__main__':
    # Example Usage (requires manual creation of Tkinter window for testing)
    # This is usually called from main_app.py

    # For direct testing, you could do:
    # root = tk.Tk()
    # root.title("Chart Utils Test")
    # root.geometry("700x500")
    # test_frame = ttk.Frame(root, padding=10)
    # test_frame.pack(expand=True, fill="both")

    # display_placeholder_chart(test_frame, "Test Placeholder")
    # Or, with dummy data:
    # plot_training_rewards(test_frame, [1.0, 1.2, 0.9, 1.5, 1.3, 1.8, 2.0, 1.9, 2.2, 2.1])
    # plot_action_distribution(test_frame, {'RLE': 150, 'NoCompression': 850})
    # root.mainloop()

    print("chart_utils.py executed. For visual tests, uncomment and run the Tkinter root loop example above.")
    print("Make sure you have matplotlib installed: pip install matplotlib")