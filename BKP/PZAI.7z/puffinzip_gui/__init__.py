# PuffinZipAI_Project/puffinzip_gui/__init__.py

# Import the main application class from main_app.py to make it
# available when the puffinzip_gui package is imported.
# Example: from puffinzip_gui import PuffinZipApp
from .main_app import PuffinZipApp

# You can also define __all__ to specify what `from puffinzip_gui import *` imports
__all__ = [
    "PuffinZipApp",
]

# Optional: Define a version for your GUI package
__version__ = "1.0.0"

# Optional: A print statement for debugging to see when the package is initialized.
# Can be removed in production.
# print(f"puffinzip_gui package (version {__version__}) initialized.")