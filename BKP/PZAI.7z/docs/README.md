# PuffinZipAI Project

This is a project for an AI that learns to compress data using RLE.
