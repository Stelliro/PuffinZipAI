# PuffinZipAI_Project/run_gui.py

import sys
import os

# Optional: Add the project root to sys.path if running this script from elsewhere
# or if the puffinzip_gui/puffinzip_ai packages are not found.
# This line assumes run_gui.py is in the PuffinZipAI_Project directory.
# If PuffinZipAI_Project itself is not in PYTHONPATH, this might be needed.
# SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
# if SCRIPT_DIR not in sys.path:
#    sys.path.insert(0, SCRIPT_DIR)

try:
    from puffinzip_gui.main_app import PuffinZipApp
    # Optional: Setup a specific logger for this runner script
    from puffinzip_ai import setup_logger  # Assuming __init__.py in puffinzip_ai exports it
    import logging
except ImportError as e:
    print(f"FATAL ERROR in run_gui.py: Could not import necessary modules: {e}")
    print("Ensure the PuffinZipAI_Project is structured correctly, with 'puffinzip_gui' and 'puffinzip_ai' packages.")
    print("You might need to run this from the PuffinZipAI_Project directory or set PYTHONPATH.")
    sys.exit(1)

if __name__ == "__main__":
    # Setup a logger specifically for the GUI launcher script itself
    # This is for logging the GUI's own startup, major errors, or shutdown.
    # The PuffinZipApp instance will create its own PuffinZipAI agent,
    # which in turn uses its own 'PuffinZipAI_Core' logger.
    gui_runner_logger = setup_logger(
        logger_name="PuffinZip_App_GUI_Runner",
        log_filename="logs/puffin_app_status_gui.log",  # Ensure 'logs' dir path is handled by logger.py
        log_level=logging.INFO,
        log_to_console=True  # Good to see GUI runner messages on console too
    )
    gui_runner_logger.info("--- PuffinZipAI GUI Application Script Starting ---")

    try:
        app = PuffinZipApp()  # PuffinZipApp (from main_app.py) initializes the PuffinZipAI agent
        app.mainloop()
    except Exception as e:
        gui_runner_logger.exception("Unhandled exception during GUI execution (run_gui.py):")
        # Also print to console in case logging itself has an issue or for immediate visibility
        import traceback

        print("\n--- FATAL GUI ERROR ---")
        traceback.print_exc()
        print("-----------------------\nAn unexpected error occurred, and the GUI had to close.")
        print("Please check the logs/puffin_app_status_gui.log and logs/puffin_ai_core.log for more details.")
    finally:
        gui_runner_logger.info("--- PuffinZipAI GUI Application Script Closed ---")