# PuffinZipAI_Project/tests/test_ai_core.py

import unittest
import numpy # For Q-table comparisons if needed

# Attempt to import the PuffinZipAI class and necessary constants
# This assumes the tests directory is at the same level as the puffinzip_ai package,
# or that the project root is in PYTHONPATH when running tests.
try:
    from puffinzip_ai import PuffinZipAI, DEFAULT_LEN_THRESHOLDS
except ImportError:
    # Fallback for running directly or if path issues, try to adjust path
    import sys
    import os
    # Add the directory containing 'puffinzip_ai' to the Python path
    # This assumes 'tests' is one level down from the project root where 'puffinzip_ai' resides.
    PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
    sys.path.insert(0, PROJECT_ROOT)
    from puffinzip_ai import PuffinZipAI, DEFAULT_LEN_THRESHOLDS


class TestPuffinZipAICore(unittest.TestCase):

    def setUp(self):
        # This method is called before each test function.
        # Create a new PuffinZipAI instance for each test to ensure isolation.
        self.ai_agent_default = PuffinZipAI()
        self.custom_thresholds = [5, 15, 30]
        self.ai_agent_custom = PuffinZipAI(len_thresholds=self.custom_thresholds)

    def test_initialization_default_thresholds(self):
        self.assertIsNotNone(self.ai_agent_default)
        self.assertEqual(self.ai_agent_default.len_thresholds, DEFAULT_LEN_THRESHOLDS)
        expected_len_cats = len(DEFAULT_LEN_THRESHOLDS) + 1
        self.assertEqual(self.ai_agent_default.NUM_LEN_CATS, expected_len_cats)
        expected_q_table_shape = (expected_len_cats * PuffinZipAI.NUM_UNIQUE_RATIO_CATS * PuffinZipAI.NUM_RUN_CATS, self.ai_agent_default.action_space_size)
        self.assertEqual(self.ai_agent_default.q_table.shape, expected_q_table_shape)

    def test_initialization_custom_thresholds(self):
        self.assertIsNotNone(self.ai_agent_custom)
        self.assertEqual(self.ai_agent_custom.len_thresholds, self.custom_thresholds)
        expected_len_cats = len(self.custom_thresholds) + 1
        self.assertEqual(self.ai_agent_custom.NUM_LEN_CATS, expected_len_cats)
        expected_q_table_shape = (expected_len_cats * PuffinZipAI.NUM_UNIQUE_RATIO_CATS * PuffinZipAI.NUM_RUN_CATS, self.ai_agent_custom.action_space_size)
        self.assertEqual(self.ai_agent_custom.q_table.shape, expected_q_table_shape)

    def test_configure_data_categories(self):
        initial_q_table_shape = self.ai_agent_default.q_table.shape
        new_thresholds_str = ["100", "200"]
        self.ai_agent_default.configure_data_categories(new_thresholds_str)
        self.assertEqual(self.ai_agent_default.len_thresholds, [100, 200])
        self.assertNotEqual(self.ai_agent_default.q_table.shape, initial_q_table_shape) # Q-table should be reshaped

        expected_len_cats = len([100, 200]) + 1
        expected_q_table_shape = (expected_len_cats * PuffinZipAI.NUM_UNIQUE_RATIO_CATS * PuffinZipAI.NUM_RUN_CATS, self.ai_agent_default.action_space_size)
        self.assertEqual(self.ai_agent_default.q_table.shape, expected_q_table_shape)

    def test_get_state_representation_simple(self):
        # Test with default thresholds [10, 20]
        # len_cat for "AAA" (len 3) should be 0
        # unique_chars = 1, ratio = 1/3 = 0.33 -> unique_ratio_cat = 0
        # max_run = 3 -> run_cat = 1
        # Expected state index: (0 * (3*3)) + (0*3) + 1 = 1
        state_aaa = self.ai_agent_default._get_state_representation("AAA")
        self.assertEqual(state_aaa, (0 * 9) + (0 * 3) + 1) # Manually calculate based on constants

        # len_cat for "ABCDEFGHIJK" (len 11) should be 1 (10 <= len < 20)
        # unique_chars = 11, ratio = 1.0 -> unique_ratio_cat = 2
        # max_run = 1 -> run_cat = 0
        # Expected state index: (1 * (3*3)) + (2*3) + 0 = 9 + 6 + 0 = 15
        state_long_unique = self.ai_agent_default._get_state_representation("ABCDEFGHIJK")
        self.assertEqual(state_long_unique, (1 * 9) + (2 * 3) + 0)

    def test_choose_action_no_exploration(self):
        # Set a known Q-table state
        state_index = 0
        self.ai_agent_default.q_table[state_index, 0] = 1.0 # Action 0 (RLE) has higher Q-value
        self.ai_agent_default.q_table[state_index, 1] = 0.5 # Action 1 (NoComp)
        chosen_action = self.ai_agent_default._choose_action(state_index, use_exploration=False)
        self.assertEqual(chosen_action, 0) # Should choose RLE

        self.ai_agent_default.q_table[state_index, 0] = 0.5
        self.ai_agent_default.q_table[state_index, 1] = 1.0 # Action 1 (NoComp) now higher
        chosen_action = self.ai_agent_default._choose_action(state_index, use_exploration=False)
        self.assertEqual(chosen_action, 1) # Should choose NoComp

    def test_update_q_table(self):
        state, action, reward, learning_rate = 0, 0, 10.0, self.ai_agent_default.learning_rate
        initial_q_value = self.ai_agent_default.q_table[state, action]
        self.ai_agent_default._update_q_table(state, action, reward)
        expected_new_q = initial_q_value + learning_rate * (reward - initial_q_value)
        self.assertAlmostEqual(self.ai_agent_default.q_table[state, action], expected_new_q, places=5)

    # Add more tests for:
    # - _handle_item_processing_for_training (rewards, stats updates)
    # - train (mocking item generation or using very small number of episodes)
    # - learn_from_folder (mocking os.listdir and file reads)
    # - batch compress/decompress (mocking files, checking output)
    # - save_model / load_model (checking if file is created, loaded values are correct)

if __name__ == '__main__':
    unittest.main()