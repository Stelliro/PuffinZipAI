# PuffinZipAI_Project/tests/test_rle_utils.py

import unittest

# Attempt to import from the package structure
try:
    from puffinzip_ai.rle_utils import (
        rle_compress,
        rle_decompress,
        RLE_ERROR_NO_COUNT,
        RLE_ERROR_BAD_COUNT,
        RLE_ERROR_NO_CHAR_AFTER_COUNT,
        RLE_DECOMPRESSION_ERRORS
    )
except ImportError:
    # Fallback for running directly or if path issues
    import sys
    import os

    PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
    sys.path.insert(0, PROJECT_ROOT)
    from puffinzip_ai.rle_utils import (
        rle_compress,
        rle_decompress,
        RLE_ERROR_NO_COUNT,
        RLE_ERROR_BAD_COUNT,
        RLE_ERROR_NO_CHAR_AFTER_COUNT,
        RLE_DECOMPRESSION_ERRORS
    )


class TestRLEUtils(unittest.TestCase):

    def test_rle_compress_empty_string(self):
        self.assertEqual(rle_compress(""), "")

    def test_rle_compress_single_char(self):
        self.assertEqual(rle_compress("A"), "1A")

    def test_rle_compress_single_run(self):
        self.assertEqual(rle_compress("AAAAA"), "5A")

    def test_rle_compress_multiple_runs(self):
        self.assertEqual(rle_compress("AAABBCDDD"), "3A2B1C3D")

    def test_rle_compress_no_runs(self):
        self.assertEqual(rle_compress("XYZ"), "1X1Y1Z")

    def test_rle_compress_with_digits(self):
        self.assertEqual(rle_compress("11122"), "3122")

    def test_rle_compress_with_spaces(self):
        self.assertEqual(rle_compress("  AAA"), "2 3A")

    def test_rle_decompress_empty_string(self):
        self.assertEqual(rle_decompress(""), "")

    def test_rle_decompress_single_char_run(self):
        self.assertEqual(rle_decompress("1A"), "A")

    def test_rle_decompress_long_run(self):
        self.assertEqual(rle_decompress("12A"), "A" * 12)

    def test_rle_decompress_multiple_runs(self):
        self.assertEqual(rle_decompress("3A2B1C3D"), "AAABBCDDD")

    def test_rle_decompress_no_runs(self):
        self.assertEqual(rle_decompress("1X1Y1Z"), "XYZ")

    def test_rle_decompress_with_digits(self):
        self.assertEqual(rle_decompress("3122"), "11122")

    def test_rle_decompress_with_spaces(self):
        self.assertEqual(rle_decompress("2 3A"), "  AAA")

    def test_rle_decompress_error_no_count_at_start(self):
        self.assertEqual(rle_decompress("A"), RLE_ERROR_NO_COUNT)
        self.assertIn(rle_decompress("A3B"), RLE_DECOMPRESSION_ERRORS)  # Could be NO_COUNT

    def test_rle_decompress_error_no_char_after_count(self):
        self.assertEqual(rle_decompress("3"), RLE_ERROR_NO_CHAR_AFTER_COUNT)
        self.assertEqual(rle_decompress("3A5"), RLE_ERROR_NO_CHAR_AFTER_COUNT)

    def test_rle_decompress_error_bad_count_implicit(self):
        # Our current rle_decompress structure might report NO_COUNT before BAD_COUNT
        # if a non-digit appears where part of a count could be, e.g. "1A2B3CDEF" -> "DEF" part is error
        self.assertIn(rle_decompress("1A2B3CDEF"), RLE_DECOMPRESSION_ERRORS)

    def test_rle_compression_decompression_identity(self):
        test_strings = ["", "A", "AAAAA", "AAABBCDDD", "XYZ", "123321", "  TEST  "]
        for s in test_strings:
            compressed = rle_compress(s)
            decompressed = rle_decompress(compressed)
            self.assertEqual(decompressed, s, f"Identity failed for '{s}' -> '{compressed}' -> '{decompressed}'")

    def test_input_type_errors(self):
        with self.assertRaises(TypeError):
            rle_compress(123)
        with self.assertRaises(TypeError):
            rle_decompress(None)
        with self.assertRaises(TypeError):
            rle_decompress([1, 2, 3])


if __name__ == '__main__':
    unittest.main()