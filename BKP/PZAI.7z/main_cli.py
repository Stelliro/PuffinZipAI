# PuffinZipAI_Project/main_cli.py

import sys
import threading  # main_ui_loop might use it (though not directly in its definition)
import os  # For constants if needed, though better from config

# Import necessary components from the puffinzip_ai package
try:
    from puffinzip_ai import (
        PuffinZipAI,
        setup_logger,
        MODEL_FILE_DEFAULT,  # For default save/load paths in CLI
        COMPRESSED_FILE_SUFFIX,  # For messages in CLI
        # DEFAULT_LEN_THRESHOLDS # PuffinZipAI class will handle its defaults
    )
    import logging  # For logging.INFO etc.
except ImportError as e:
    print(f"FATAL ERROR in main_cli.py: Could not import from puffinzip_ai package: {e}")
    print("Ensure the PuffinZipAI_Project is structured correctly and Python can find the puffinzip_ai package.")
    print("You might need to run this from the PuffinZipAI_Project directory or set PYTHONPATH.")
    sys.exit(1)


# --- main_ui_loop function (moved from the old PuffinZipAI.py) ---
def main_ui_loop(ai_agent_instance_cli):
    # This specific CLI logger is for the interactions within this loop.
    # The ai_agent_instance_cli will use its own 'PuffinZipAI_Core' logger for its operations.
    cli_menu_logger = setup_logger(
        logger_name="PuffinZipAI_CLI_Menu",  # More specific name
        log_filename="logs/puffin_cli_menu_interactions.log",  # Specific file
        log_level=logging.INFO,
        log_to_console=False  # Assume console print is enough for direct feedback
    )
    cli_menu_logger.info("PuffinZipAI Command Line Interface Menu Loop started.")

    # Attempt to load default model at CLI start using the imported constant
    if not ai_agent_instance_cli.load_model(MODEL_FILE_DEFAULT):
        # load_model itself will send messages to its queue/print, and log
        cli_menu_logger.info(
            f"Default model ({MODEL_FILE_DEFAULT}) not loaded on CLI startup or was reset by AI agent.")

    while True:
        print("\nPuffinZipAI CLI Menu:")
        menu_options = {
            "1": "Train AI (Random Data)", "2": "Train AI (Learn from Folder)",
            "3": "Batch Compress Folder", "4": "Batch Decompress Folder",
            "5": "Test AI on random items", "6": "Compress a specific item using AI",
            "7": "Decompress a specific item (RLE)", "8": "View Q-Table Summary & Config",
            "9": "Configure Data Categories (Resets Model)", "10": "Save Learned Model",
            "11": "Load Learned Model", "12": "Exit"
        }
        for k, v in menu_options.items(): print(f"{k}. {v}")
        choice = input(f"Enter your choice (1-{len(menu_options)}): ").strip()
        cli_menu_logger.debug(f"CLI Menu choice: {choice}")

        if choice == '1':
            try:
                ep_input = input("Random training episodes (e.g., 10000, or 'c' for continuous): ").strip().lower()
                batch_s_input = input("Batch size for updates (e.g., 1, 10, 100; default 1): ").strip()
                batch_size = int(batch_s_input) if batch_s_input.isdigit() and int(batch_s_input) > 0 else 1
                if batch_size == 1 and batch_s_input not in ['1', '']: cli_menu_logger.warning(
                    f"Invalid CLI batch size '{batch_s_input}', defaulting to 1.")

                if ep_input == 'c':
                    ai_agent_instance_cli.train(run_continuously=True, batch_size=batch_size)
                else:
                    num_ep = int(ep_input)
                    if num_ep > 0:
                        ai_agent_instance_cli.train(num_episodes=num_ep, batch_size=batch_size)
                    else:
                        print("Episodes must be > 0.")
            except ValueError:
                print("Invalid input for episodes or batch size.")
                cli_menu_logger.warning("Invalid random train episode/batch input from CLI.")
        elif choice == '2':
            folder_path = input("Enter path to folder with text files to LEARN from: ").strip()
            if not os.path.isdir(folder_path):
                print(f"Error: Folder '{folder_path}' not found.")
                cli_menu_logger.error(f"Learn from folder: Path not found '{folder_path}' by CLI user.")
            else:
                batch_s_input = input("Batch size for updates (e.g., 1, 10, 100; default 1): ").strip()
                batch_size = int(batch_s_input) if batch_s_input.isdigit() and int(batch_s_input) > 0 else 1
                if batch_size == 1 and batch_s_input not in ['1', '']: cli_menu_logger.warning(
                    f"Invalid CLI batch size '{batch_s_input}', defaulting to 1.")

                run_cont_input = input("Learn from folder continuously? (y/n, default: n): ").strip().lower()
                run_continuously_folder = run_cont_input.startswith('y')
                ext_input = input("File extensions for learning (e.g., .txt,.log default .txt): ").strip().lower()
                extensions = [ext.strip() for ext in ext_input.split(',') if
                              ext.strip().startswith('.')] if ext_input else ['.txt']
                if not extensions: extensions = ['.txt']
                ai_agent_instance_cli.learn_from_folder(folder_path, allowed_extensions=extensions,
                                                        run_continuously=run_continuously_folder, batch_size=batch_size)
        elif choice == '3':
            input_f = input("INPUT folder path to batch compress: ").strip()
            output_f = input("OUTPUT folder path for compressed files: ").strip()
            if not input_f or not output_f:
                print("Input/Output folder paths required.")
            elif input_f == output_f:
                print("Error: Input/Output folders must be different.")
            else:
                ext_input = input("SOURCE file extensions (e.g., .txt,.log default .txt,.log,.csv): ").strip().lower()
                # Using constants from config via puffinzip_ai is cleaner if these defaults are there
                from puffinzip_ai.config import DEFAULT_BATCH_COMPRESS_EXTENSIONS  # Example
                default_exts = DEFAULT_BATCH_COMPRESS_EXTENSIONS

                source_extensions = [ext.strip() for ext in ext_input.split(',') if
                                     ext.strip().startswith('.')] if ext_input else default_exts
                if not source_extensions: source_extensions = default_exts
                ai_agent_instance_cli.batch_compress_folder(input_f, output_f, allowed_extensions=source_extensions)
        elif choice == '4':
            input_f = input(f"INPUT folder (esp. *{COMPRESSED_FILE_SUFFIX}): ").strip()  # Using imported constant
            output_f = input("OUTPUT folder for decompressed files: ").strip()
            if not input_f or not output_f:
                print("Input/Output folder paths required.")
            elif input_f == output_f:
                print("Error: Input/Output folders must be different.")
            else:
                ai_agent_instance_cli.batch_decompress_folder(input_f, output_f)
        elif choice == '5':
            try:
                num_items_str = input("Number of random items to test (e.g., 5): ").strip()
                num_items = int(num_items_str)
                if num_items > 0:
                    ai_agent_instance_cli.test_agent_on_random_items(num_items)
                else:
                    print("Number of items must be > 0.")
            except ValueError:
                print("Invalid input for number of items.")
                cli_menu_logger.warning("Invalid test item count input from CLI.")
        elif choice == '6':
            ai_agent_instance_cli.compress_user_item(input("Enter text item to compress: "))
        elif choice == '7':
            ai_agent_instance_cli.decompress_user_item_rle(input("Enter RLE-compressed text to decompress: "))
        elif choice == '8':
            ai_agent_instance_cli.display_q_table_summary()
        elif choice == '9':
            print(
                f"Current thresholds: {ai_agent_instance_cli.len_thresholds}. WARNING: Changing resets model and exploration rate.")
            thresholds_str = input("New comma-separated length thresholds (e.g., 10,25,50): ")
            ai_agent_instance_cli.configure_data_categories(
                thresholds_str.split(','))  # AI method handles user feedback
        elif choice == '10':
            filename_to_save = input(
                f"Filename to save model (default: {MODEL_FILE_DEFAULT}): ").strip() or MODEL_FILE_DEFAULT
            ai_agent_instance_cli.save_model(filename_to_save)  # AI method handles user feedback
        elif choice == '11':
            filename_to_load = input(
                f"Filename to load model (default: {MODEL_FILE_DEFAULT}): ").strip() or MODEL_FILE_DEFAULT
            ai_agent_instance_cli.load_model(filename_to_load)  # AI method handles user feedback
        elif choice == '12':
            print("Exiting PuffinZipAI CLI.")
            cli_menu_logger.info("PuffinZipAI CLI exited by user choice.")
            break
        else:
            print("Invalid choice. Please try again.")
            cli_menu_logger.warning(f"Invalid CLI menu choice: {choice}")


if __name__ == "__main__":
    # This logger is for the main_cli.py script's own execution status (start/stop/crash)
    # It's different from the cli_menu_logger inside main_ui_loop.
    app_status_logger = setup_logger(
        logger_name="PuffinZip_App_CLI_Runner",
        log_filename="logs/puffin_app_status_cli.log",  # Ensure 'logs' dir path is handled by logger
        log_level=logging.INFO
    )
    app_status_logger.info("--- PuffinZipAI CLI Application Script Starting ---")

    puffin_ai_instance = PuffinZipAI()  # The AI instance uses its own 'PuffinZipAI_Core' logger
    # initialized within its __init__ method.
    try:
        main_ui_loop(puffin_ai_instance)  # Pass the AI instance to the loop
    except Exception as e:
        app_status_logger.exception("Unhandled exception in main_cli.py execution:")
        print(f"An unexpected error occurred in the CLI: {e}")  # User feedback for crash
    finally:
        app_status_logger.info("--- PuffinZipAI CLI Application Script Closed ---")